package com.engine.app.folders;

import android.util.Log;

import java.io.File;

public final class SoundFileChecker {

    private static final String TAG = SoundFileChecker.class.getSimpleName();
    
    /**
     * Contains all possible places to check binaries
     */
    private static final String[] pathList;
    private static final String soundFilePath = SoundFile.SOUND_ADD_FILE;
    
    /**
     * The binary which grants the root privileges
     */
    private static final String KEY_SOUND_FILE = soundFilePath;
    
    static {
        pathList = new String[]{
            SoundFile.SOUND_FOLDER + "/"           
        };
    }
    
    public static boolean isSoundExist() {
        return doesFileExists(KEY_SOUND_FILE);
    }
    
    /**
     * Checks the all path until it finds it and return immediately.
     *
     * @param value must be only the binary name
     * @return if the value is found in any provided path
     */
    private static boolean doesFileExists(String value) {
        boolean result = false;
        for (String path : pathList) {
            File file = new File(path + "/" + value);
            result = file.exists();
            if (result) {
                Log.d(TAG, path + " contains savedata binary");
                break;
            }
        }
        return result;
    }
}
