package com.engine.app.fragments;

import android.Manifest;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBar.OnNavigationListener;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.UriPermission;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.database.Cursor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import com.engine.R;
import com.engine.app.folders.FolderMe;
import com.engine.app.folders.FolderMePreference;
import com.engine.app.folders.archiver.Un7Zip;
import com.engine.app.folders.archiver.callback.ExtractCallback;
import com.engine.app.analytics.AnalyticPermissions;
import com.engine.app.analytics.AnalyticsActivity;
import com.engine.app.analytics.AnalyticsFragment;
import com.engine.app.settings.Settings;

public class UnzipFragment extends Fragment implements View.OnClickListener {

	public static String TAG = UnzipFragment.class.getSimpleName();

    private static final int REQUEST_READ_EXTERNAL_STORAGE = 1;
    private AnalyticsActivity mActivity;
    private Context mContext;
    private Toolbar mToolbar;
	private boolean haveMedia;
	private Settings mSettings;

	private SharedPreferences Sp;
	
    private TextView mText7zVersion;
    private TextView mTextFilePath;
    private Button mButtonChooseFile;
    private Button mButtonExtract;
    private Button mButtonExtractAsset;
    private TextView mTextOutputPath;

    private String mOutputPath;
    private String mInputFilePath;
    private ProgressDialog mProgressDialog;
    private ExecutorService mExecutor;
	private AnalyticPermissions mAnalytics;


    public static UnzipFragment newInstance() {
        UnzipFragment fragment = new UnzipFragment();       
        return fragment;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_unzip, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        mActivity = (AnalyticsActivity)getActivity();
        mContext = getActivity();
        mToolbar = (Toolbar) view.findViewById(R.id.toolbar);
        if (mToolbar != null) {
            mActivity.setSupportActionBar(mToolbar);
            final ActionBar actionbar = mActivity.getSupportActionBar();
            actionbar.setTitle("Home"); 
        }
		Sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		mSettings = new Settings(mContext);
        mText7zVersion = view.findViewById(R.id.text_7z_version);
		mTextFilePath = view.findViewById(R.id.text_file_path);
		mButtonChooseFile = view.findViewById(R.id.button_choose_file);
		mButtonChooseFile.setOnClickListener(this);
		mButtonExtract = view.findViewById(R.id.button_extract);
		mButtonExtract.setOnClickListener(this);
		mButtonExtractAsset = view.findViewById(R.id.button_extract_asset);
		mButtonExtractAsset.setOnClickListener(this);
		mTextOutputPath = view.findViewById(R.id.text_output_path);

		mProgressDialog = new ProgressDialog(mContext);
        mExecutor = Executors.newSingleThreadExecutor();
        mText7zVersion.setText(Un7Zip.getLzmaVersion());
		mAnalytics = AnalyticPermissions.with(mContext);
        File outFile = mContext.getExternalFilesDir("extracted");
        if (outFile == null || !outFile.exists()) {
            outFile = mContext.getFilesDir();
        }
        mOutputPath = outFile.getPath();
        mTextOutputPath.setText(mOutputPath);
		haveMedia = mSettings.mediaUri != null && (FolderMe.fileExists(mContext, mSettings.mediaUri) || mSettings.mediaUri.getScheme().startsWith("http"));

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.add("Test")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {

                    return false;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        inflater.inflate(R.menu.menu_application, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_about:
				mActivity.switchFragment(AnalyticsFragment.newInstance("Home"));
                return true;
            case R.id.action_settings:

                return true;    
            case R.id.action_exit:
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
	public void onClick(View view) {
		switch (view.getId()) {
			case R.id.button_choose_file:
				final Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
				intent.addCategory(Intent.CATEGORY_OPENABLE);
				intent.setType("*/*");

				/*if (Build.VERSION.SDK_INT >= 26)
				 intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, Uri.parse(FolderMePreference.getWorkingFile(this)));*/
				startActivityForResult(intent, REQUEST_READ_EXTERNAL_STORAGE);

				break;
			case R.id.button_extract:
				mAnalytics.requestPermission(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, new AnalyticPermissions.OnAnalyticsPermissionListener(){
						@Override
						public void onGranted(String message, List<String> permissions) {
							if (haveMedia) {
								String zipFile = mSettings.mediaUri.getPath();
								if (TextUtils.isEmpty(zipFile)) {
									showMessage("Please Select 7z File First!");
									return;
								} 
								doExtractFile(zipFile);
							}
						}

						@Override
						public void onDenied(String message, List<String> permissions) {
							showMessage("Permission Denied!");
						}
					});	
				break;
			case R.id.button_extract_asset:
				mAnalytics.requestPermission(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, new AnalyticPermissions.OnAnalyticsPermissionListener(){	
				    	@Override
						public void onGranted(String message, List<String> permissions) {
							String assetFile = "FolderMe.7z";
							if (TextUtils.isEmpty(assetFile)) {
								showMessage("Asset File Not Found!");
								return;
							}
							doExtractAssets(assetFile);
						}

						@Override
						public void onDenied(String message, List<String> permissions) {
							showMessage("Permission Denied!");
						}
					});
				break;
		}
	}

	/**
     * real extract process
     */
    private void doExtractFile(final String file7Zip) {
        mProgressDialog.show();
		mExecutor.submit(new Runnable(){
				@Override
				public void run() {
					Un7Zip.extractFile(file7Zip, mOutputPath, new ExtractCallback() {
							@Override
							public void onProgress(final String name, final long size) {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											mProgressDialog.setMessage("name: " + name + "\nsize: " + size);
										}
									});
							}

							@Override
							public void onError(final int errorCode, final String message) {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage(message);
											mProgressDialog.dismiss();
										}
									});
							}

							@Override
							public void onSucceed() {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage("Succeed!!");
											mProgressDialog.dismiss();
										}
									});
							}

						});
				}
			});
    }


	/**
     * real extract process
     */
    private void doExtractAssets(final String file7Zip) {
		mProgressDialog.show();
		mExecutor.submit(new Runnable(){
				@Override
				public void run() {
					Un7Zip.extractAsset(mContext.getAssets(), file7Zip,
						mOutputPath, new ExtractCallback() {
							@Override
							public void onProgress(final String name, final long size) {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											mProgressDialog.setMessage("name: " + name + "\nsize: " + size);
										}
									});
							}

							@Override
							public void onError(final int errorCode, final String message) {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage(message);
											mProgressDialog.dismiss();
										}
									});
							}

							@Override
							public void onSucceed() {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage("Succeed!!");
											mProgressDialog.dismiss();
										}
									});
							}
						});
				}
			});
    }

	@Override
	public void onActivityResult(final int requestCode, int resultCode, Intent resultData) {
		if (requestCode == REQUEST_READ_EXTERNAL_STORAGE) {
            if (resultCode == Activity.RESULT_OK) {
                final Uri uri = resultData.getData();
                boolean uriAlreadyTaken = false;

                // https://commonsware.com/blog/2020/06/13/count-your-saf-uri-permission-grants.html
                final ContentResolver contentResolver = mContext.getContentResolver();
                for (UriPermission persistedUri : contentResolver.getPersistedUriPermissions()) {
                    if (persistedUri.getUri().equals(uri)) {
                        uriAlreadyTaken = true;
                    } else {
                        contentResolver.releasePersistableUriPermission(persistedUri.getUri(), Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }
                }

                if (!uriAlreadyTaken) {
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (SecurityException e) {
                        e.printStackTrace();
                    }
                }
				Log.i(TAG, "Uri: " + uri.toString());
				mSettings.updateMedia(uri, resultData.getType());          
            }
		} else {
            super.onActivityResult(requestCode, resultCode, resultData);
        }
	}

	public void choosFile(String uri) {
		mInputFilePath = uri;
		showMessage("Choose File:" + mInputFilePath);
		mTextFilePath.setText(mInputFilePath);
	}

	@Override
	public void onResume() {
		super.onResume();
		haveMedia = mSettings.mediaUri != null && (FolderMe.fileExists(mContext, mSettings.mediaUri) || mSettings.mediaUri.getScheme().startsWith("http"));	
		if (haveMedia)
			choosFile(mSettings.mediaUri.getPath());    
	}

	@Override
    public void onDestroy() {
        mExecutor.shutdownNow();
        super.onDestroy();	
    }

    private void showMessage(String msg) {
        Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
    }
}
