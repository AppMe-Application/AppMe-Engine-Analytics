package com.engine.app.listeners;

public interface OnRequestHandlerListener {
    void onStart();
    void onFinish();
}
