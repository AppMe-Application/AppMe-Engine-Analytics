package com.engine.app.folders;

import android.support.annotation.Nullable;
import android.support.annotation.NonNull;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.text.TextUtils;
import android.content.pm.PackageManager;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.ref.WeakReference;


import com.engine.R;
import com.engine.AppController;
import com.engine.app.utils.FileUtils;
import com.engine.app.utils.Utils;
import com.engine.app.tasks.DefaultThreadManager;

public class FolderMe {
    private Context context;

    /** Note that this is a symlink on the Android M preview. */
    @SuppressLint("SdCardPath")
    public static String EXTERNAL_DIR = getExternalStorageDirectory();
    public static String FOLDER = getFolderMe();
    //Folder For PackageArchive
    public static String FOLDER_APK = FOLDER + "/1.Apk";
    public static String FOLDER_APK_BACKUP = FOLDER_APK + "/Backup";
    public static String FOLDER_APK_DOWNLOAD = FOLDER_APK + "/Download";

    //Folder For Image
    public static String FOLDER_IMAGE = FOLDER + "/2.Image";
    public static String FOLDER_IMAGE_CONVERT = FOLDER_IMAGE + "/Convert";
    public static String FOLDER_IMAGE_DOWNLOAD = FOLDER_IMAGE + "/Download";
    public static String FOLDER_IMAGE_PROJECTS = FOLDER_IMAGE + "/Projects";

    //Folder For Audio
    public static String FOLDER_AUDIO = FOLDER + "/3.Audio";
    public static String FOLDER_AUDIO_RECORDER = FOLDER_AUDIO + "/Recorder";
    public static String FOLDER_AUDIO_DOWNLOAD = FOLDER_AUDIO + "/Download";
    public static String FOLDER_AUDIO_CONVERT = FOLDER_AUDIO + "/Convert";

    //Folder For Video
    public static String FOLDER_VIDEO = FOLDER + "/4.Video";
    public static String FOLDER_VIDEO_RECORDER = FOLDER_VIDEO + "/Recorder";
    public static String FOLDER_VIDEO_DOWNLOAD = FOLDER_VIDEO + "/Download";
    public static String FOLDER_VIDEO_PROJECTS = FOLDER_VIDEO + "/Projects";

    //Folder For YouTube
    public static String FOLDER_YOUTUBE = FOLDER_VIDEO + "/Youtube";
    public static String FOLDER_YOUTUBE_ANALYTICS = FOLDER_YOUTUBE + "/Analytics";
    public static String FOLDER_YOUTUBE_DOWNLOAD = FOLDER_YOUTUBE + "/Download";

    //Folder For Ebook
    public static String FOLDER_EBOOK = FOLDER + "/5.Ebook";
    public static String FOLDER_EBOOK_PROJECTS = FOLDER_EBOOK + "/Projects";
    public static String FOLDER_EBOOK_DOWNLOAD = FOLDER_EBOOK + "/Download";

    //Folder For Script
    public static String FOLDER_SCRIPTME = FOLDER + "/6.ScriptMe";
    public static String FOLDER_SCRIPTME_PROJECTS = FOLDER_SCRIPTME + "/Projects";
    public static String FOLDER_SCRIPTME_DOWNLOAD = FOLDER_SCRIPTME + "/Download";

    //Folder For Archive
    public static String FOLDER_ARCHIVE = FOLDER + "/7.Archive";
    public static String FOLDER_ARCHIVE_DOWNLOAD = FOLDER_ARCHIVE + "/Download";
    public static String FOLDER_ARCHIVE_EXTRACTION = FOLDER_ARCHIVE + "/Extracted";
    public static String FOLDER_ARCHIVE_ARCHIVES = FOLDER_ARCHIVE + "/Archives";

	public static final String DEFAULT_ROOT = "/data/data/com.engine/files";
	public static final String DEFAULT_HOME = DEFAULT_ROOT + "/home";

	/** Note that this is a symlink on the Android M preview. */
    @SuppressLint("SdCardPath")
    public static final String FILES_PATH = "/data/data/com.engine/files";
    public static final String PREFIX_PATH = FILES_PATH + "/usr";
    public static final String HOME_PATH = FILES_PATH + "/home";

    //WebServer Folder
    public static final String HOME_WEB_PATH = FOLDER_SCRIPTME + "/web";
    public static final String FOLDER_WEB_CLIENT = HOME_WEB_PATH + "/client";
    public static final String FOLDER_WEB_EDITOR = HOME_WEB_PATH + "/editor";
    public static final String FOLDER_WEB_TERMINAL = HOME_WEB_PATH + "/terminal";
    public static final String FOLDER_FILE_TRANSFER = HOME_WEB_PATH + "/folders";
	public static File ROOT;
	public static File HOME;

	public String dirName = FolderMe.class.getSimpleName();

    public FolderMe() {}
	public static void init() {
		final AppController app = AppController.getInstance();
		ROOT = app.getFilesDir();
		HOME = mkdirIfNotExits(app.getHomeDir());

    }

    private FolderMe(final Context context) {
        this.context = context;
		DefaultThreadManager.getInstance().execute(new Runnable() {
				@Override
				public void run() {
					try {

						if (externalAvailable()) {
							/*File mDefaultDir = new File(getExternalStorageDirectory() + File.separator + context.getString(context.getApplicationInfo().labelRes), ".nomedia");
							 mDefaultDir.getParentFile().mkdirs();
							 if (!mDefaultDir.exists()) {
							 try {
							 mDefaultDir.createNewFile();                    
							 } catch (IOException io) {
							 io.getMessage();
							 }
							 }*/

							File mExternalDir = context.getExternalFilesDir(null);
							mExternalDir.getParentFile().mkdirs();
							if (!mExternalDir.exists()) {
								mExternalDir.mkdirs();
							}

							File mScanning = context.getExternalFilesDir("scanning");
							mScanning.getParentFile().mkdirs();
							if (!mScanning.exists()) {
								mScanning.mkdirs();
							}

							File mLog = context.getExternalFilesDir("log");
							mLog.getParentFile().mkdirs();
							if (!mLog.exists()) {
								mLog.mkdirs();
							}

							File mTemp = context.getExternalFilesDir("temp");
							mTemp.getParentFile().mkdirs();
							if (!mTemp.exists()) {
								mTemp.mkdirs();
							}

							File mObbFolder = context.getObbDir();
							mObbFolder.getParentFile().mkdirs();
							if (!mObbFolder.exists()) {
								mObbFolder.mkdirs();
							}

							File mInternalDir = context.getFilesDir();
							mInternalDir.getParentFile().mkdirs();
							if (!mInternalDir.exists()) {
								mInternalDir.mkdirs();
								mInternalDir.setExecutable(true, false);
							}

							File mDataDir = new File(getDataDir(context));
							mDataDir.getParentFile().mkdirs();
							if (!mDataDir.exists()) {
								mDataDir.mkdirs();
								mDataDir.setExecutable(true, false);
							} 

							File mSupportDir = new File(mDataDir, "support");
							mSupportDir.getParentFile().mkdirs();
							if (!mSupportDir.exists()) {
								mSupportDir.mkdirs();
								mSupportDir.setExecutable(true, false);
							} 


							File mExternalCacheDir = context.getCacheDir();
							mExternalCacheDir.getParentFile().mkdirs();
							if (!mExternalCacheDir.exists()) {
								mExternalCacheDir.mkdirs();
							} 

							File mInternalCacheDir = context.getExternalCacheDir();
							mInternalCacheDir.getParentFile().mkdirs();
							if (!mInternalCacheDir.exists()) {
								mInternalCacheDir.mkdirs();
							}          
						}  
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
    }

    public static FolderMe with(Context context) {
        return new FolderMe(context);
    }

	public FolderMe setFolder(String folder) {
        if (externalAvailable()) {
            File mFolderMe = new File(folder);
            if (!mFolderMe.exists()) {
                mFolderMe.mkdirs();
            }
        }
        return this;
    }

	public FolderMe serFolderName(String dirName) {
		this.dirName = dirName;
		return this;
	}

	public String getFolderName() {       
        return dirName;
    }

    public static class DirectoryNotEmptyException extends IOException {
        public DirectoryNotEmptyException(File file) {
            super("Directory " + file.getName() + " is not empty");
        }
    }

    public static class FileAlreadyExistsException extends IOException {

        public FileAlreadyExistsException(File file) {
            super("File " + file.getName() + " already exists in destination");
        }
    }

    public static void deleteEmptyFolders(Collection<File> directories) throws DirectoryNotEmptyException {
        for (File file : directories) {
			if (file.isDirectory()) {           
                //FileMe.deleteFiles(Arrays.asList(file.listFiles()));
                file.delete();
            } else throw new DirectoryNotEmptyException(file);
		}
    }

    public void setOnFolderMeListener(final OnFolderMeListener mOnFolderMeListener) {
		final Activity activity = (Activity)context;
		DefaultThreadManager.getInstance().execute(new Runnable() {
				@Override
				public void run() {
					try {
						activity.runOnUiThread(new Runnable(){
								@Override
								public void run() {
									if (externalAvailable()) {
										ArrayList<File> folder = new ArrayList<File>();
										//Default Folder
										folder.add(new File(FOLDER));
										//Folder Apk
										folder.add(new File(FOLDER_APK));
										folder.add(new File(FOLDER_APK_BACKUP));
										folder.add(new File(FOLDER_APK_DOWNLOAD));
										//Folder Image
										folder.add(new File(FOLDER_IMAGE));
										folder.add(new File(FOLDER_IMAGE_CONVERT));
										folder.add(new File(FOLDER_IMAGE_DOWNLOAD));
										folder.add(new File(FOLDER_IMAGE_PROJECTS));
										//Folder Audio
										folder.add(new File(FOLDER_AUDIO));
										folder.add(new File(FOLDER_AUDIO_CONVERT));
										folder.add(new File(FOLDER_AUDIO_DOWNLOAD));
										folder.add(new File(FOLDER_AUDIO_RECORDER));
										//Folder Video
										folder.add(new File(FOLDER_VIDEO));
										folder.add(new File(FOLDER_VIDEO_PROJECTS));
										folder.add(new File(FOLDER_VIDEO_DOWNLOAD));
										folder.add(new File(FOLDER_VIDEO_RECORDER));
										//Folder Video
										folder.add(new File(FOLDER_YOUTUBE));
										folder.add(new File(FOLDER_YOUTUBE_ANALYTICS));
										folder.add(new File(FOLDER_YOUTUBE_DOWNLOAD));
										//Folder ScriptMe
										folder.add(new File(FOLDER_SCRIPTME));
										folder.add(new File(FOLDER_SCRIPTME_PROJECTS));
										folder.add(new File(FOLDER_SCRIPTME_DOWNLOAD));
										//Folder Archive
										folder.add(new File(FOLDER_ARCHIVE));
										folder.add(new File(FOLDER_ARCHIVE_DOWNLOAD));
										folder.add(new File(FOLDER_ARCHIVE_EXTRACTION));
										folder.add(new File(FOLDER_ARCHIVE_ARCHIVES));
										//Folder Ebook
										folder.add(new File(FOLDER_EBOOK));
										folder.add(new File(FOLDER_EBOOK_DOWNLOAD));
										folder.add(new File(FOLDER_EBOOK_PROJECTS));

										for (int i = 0; i != folder.size(); i++) {
											for (File dir : folder) {
												setFolder(dir.getAbsolutePath());
											}
										}

										boolean isSound = SoundFileChecker.isSoundExist();
										if (isSound) {
											String message = "Success";
											mOnFolderMeListener.onSuccess(message);

										} else {
											AssetMe mAsset = AssetMe.with(activity);
											mAsset.extract();
											mAsset.setOnAssetsManagerListener(new AssetMe.OnAssetsManagerListener(){
													@Override
													public void onSuccess(String path) {
														String message = "Success";
														mOnFolderMeListener.onSuccess(message);									
													}

													@Override
													public void onFailed(String message) {
														mOnFolderMeListener.onFailed(message);									
													}
												});
										}

									}
								}
							});
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
    }

    //AppMe Folder In External Storage
    public static String getFolderMe() {       
        return getExternalStorageDirectory() + "/" + Utils.getApp().getString(Utils.getApp().getApplicationInfo().labelRes);
    }

    public static String getSubFolder(File folderName) {
        String type = folderName.getName();
        if (externalAvailable()) {
            File root = Environment.getExternalStorageDirectory();
            File appRoot = new File(root, folderName.getName());
            appRoot.mkdirs();
            String folder = appRoot.getAbsolutePath();
            if (TextUtils.isEmpty(type)) {
                return folder;
            }

            File dir = new File(appRoot, type);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            String folderMe = dir.getAbsolutePath();
            return folderMe;
        }
        throw new RuntimeException("External storage device is not available.");

    }

    public static File getSubFolder(String folder) {
        String type = folder;
        if (externalAvailable()) {
            File root = Environment.getExternalStorageDirectory();
            File appRoot = new File(root, folder);
            appRoot.mkdirs();
            if (TextUtils.isEmpty(type)) {
                return appRoot;
            }

            File dir = new File(appRoot, type);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            return dir;
        }
        throw new RuntimeException("External storage device is not available.");
    }


    public static File getFolderApk() {
        return new File(FOLDER_APK);
    }

    public static File getFolderApkDownload() {
        return new File(FOLDER_APK_DOWNLOAD);
    }

    public static File getFolderApkBackup() {
        return new File(FOLDER_APK_BACKUP);
    }

    public static File getFolderImage() {
        return new File(FOLDER_IMAGE);
    }

    public static File getFolderImageDownload() {
        return new File(FOLDER_IMAGE_DOWNLOAD);
    }

    public static File getFolderImageProjects() {
        return new File(FOLDER_IMAGE_PROJECTS);
    }

    public static File getFolderImageConvert() {
        return new File(FOLDER_IMAGE_CONVERT);
    }

    public static File getFolderAudio() {
        return new File(FOLDER_AUDIO);
    }

    public static File getFolderAudioDownload() {
        return new File(FOLDER_AUDIO_DOWNLOAD);
    }

    public static File getFolderAudioConvert() {
        return new File(FOLDER_AUDIO_CONVERT);
    }

    public static File getFolderAudioRecord() {
        return new File(FOLDER_AUDIO_RECORDER);
    }

    public static File getFolderVideo() {
        return new File(FOLDER_VIDEO);
    }

    public static File getFolderVideoDownload() {
        return new File(FOLDER_VIDEO_DOWNLOAD);
    }

    public static File getFolderVideoProjects() {
        return new File(FOLDER_VIDEO_PROJECTS);
    }

    public static File getFolderVideoRecord() {
        return new File(FOLDER_VIDEO_RECORDER);
    }

    public static File getFolderYouTube() {
        return new File(FOLDER_YOUTUBE);
    }

    public static File getFolderYouTubeDownload() {
        return new File(FOLDER_YOUTUBE_DOWNLOAD);
    }

    public static File getFolderYouTubeAnalytics() {
        return new File(FOLDER_YOUTUBE_ANALYTICS);
    }

    public static File getFolderEbook() {
        return new File(FOLDER_EBOOK);
    }

    public static File getFolderEbookDownload() {
        return new File(FOLDER_EBOOK_DOWNLOAD);
    }

    public static File getFolderEbookProjects() {
        return new File(FOLDER_EBOOK_PROJECTS);
    }

    public static File getFolderScriptMe() {
        return new File(FOLDER_SCRIPTME);
    }

    public static File getFolderScriptMeDownload() {
        return new File(FOLDER_SCRIPTME_DOWNLOAD);
    }

    public static File getFolderScriptMeProjects() {
        return new File(FOLDER_SCRIPTME_PROJECTS);
    }

    public static File getWebFolder() {
        File mWeb_Path = new File(HOME_WEB_PATH);
        if (!mWeb_Path.exists()) {
            mWeb_Path.mkdirs();
        }   
        return mWeb_Path;
    }

    public static File getWebTerminal() {
        File mWeb_Path = new File(FOLDER_WEB_TERMINAL);
        if (!mWeb_Path.exists()) {
            mWeb_Path.mkdirs();
        }   
        return mWeb_Path;
    }

    public static File getWebEditor() {
        File mWeb_Path = new File(FOLDER_WEB_EDITOR);
        if (!mWeb_Path.exists()) {
            mWeb_Path.mkdirs();
        }   
        return mWeb_Path;
    }

    public static File getWebClient() {
        File mWeb_Path = new File(FOLDER_WEB_CLIENT);
        if (!mWeb_Path.exists()) {
            mWeb_Path.mkdirs();
        }   
        return mWeb_Path;
    }

    public static File getFileTransfer() {
        File filePath = new File(FOLDER_FILE_TRANSFER);
        if (!filePath.exists()) {
            filePath.mkdirs();
        }   
        return filePath;
    }

    public static File getScriptFolder() {
        File filePath = new File(FOLDER_SCRIPTME_PROJECTS);
        if (!filePath.exists()) {
            filePath.mkdirs();
        }   
        return filePath;
    }

    public static String getServerIP() {
        return HOME_WEB_PATH + "/ip-address.json";
    }

	public static boolean fileExists(final Context context, final Uri uri) {
        if ("file".equals(uri.getScheme())) {
            final File file = new File(uri.getPath());
            return file.exists();
        } else {
            try {
                final InputStream inputStream = context.getContentResolver().openInputStream(uri);
                inputStream.close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

	public static File mkdirIfNotExits(File in) {
		if (in != null && !in.exists()) {
			FileUtils.createOrExistsDir(in);
		}

		return in;
	}
    /**
     *get the internal or outside sd card path
     * @param is_removale true is is outside sd card
     * */
    public static String getExternalStorageDirectory() {
        return Environment.getExternalStorageDirectory().getAbsolutePath();   
    }

    public static String getExternalStoragePublicDirectory(String directory) {
        return Environment.getExternalStoragePublicDirectory(directory).getAbsolutePath();   
    }

    public static String getFolderDCIM() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath();   
    }

    public static String getInternalStorageDirectory(Context mContext, boolean is_removale) {

        StorageManager mStorageManager = (StorageManager) mContext.getSystemService(Context.STORAGE_SERVICE);
        Class<?> storageVolumeClazz = null;
        try {
            storageVolumeClazz = Class.forName("android.os.storage.StorageVolume");
            Method getVolumeList = mStorageManager.getClass().getMethod("getVolumeList");
            Method getPath = storageVolumeClazz.getMethod("getPath");
            Method isRemovable = storageVolumeClazz.getMethod("isRemovable");
            Object result = getVolumeList.invoke(mStorageManager);
            final int length = Array.getLength(result);
            for (int i = 0; i < length; i++) {
                Object storageVolumeElement = Array.get(result, i);
                String path = (String) getPath.invoke(storageVolumeElement);
                boolean removable = (Boolean) isRemovable.invoke(storageVolumeElement);
                if (is_removale == removable) {
                    return path;
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

	public static File getFileDir(Context context) {
        return getFileDir(context, null);
    }

    public static File getFileDir(Context context, @Nullable String type) {
        File root = context.getFilesDir();
        if (TextUtils.isEmpty(type)) {
            return root;
        } else {
            File dir = new File(root, type);
            createDir(dir);
            return dir;
        }
    }

    public static boolean externalAvailable() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    public static File getExternalDir(Context context) {
        return getExternalDir(context, null);
    }

    public static File getExternalDir(Context context, @Nullable String type) {
        if (externalAvailable()) {
            if (TextUtils.isEmpty(type)) {
                return context.getExternalFilesDir(null);
            }

            File dir = context.getExternalFilesDir(type);
            if (dir == null) {
                dir = context.getExternalFilesDir(null);
                dir = new File(dir, type);
                createDir(dir);
            }

            return dir;
        }
        throw new RuntimeException("External storage device is not available.");
    }

    public static File getRootDir() {
        return getRootDir(null);
    }

    public static File getRootDir(@Nullable String type) {
        if (externalAvailable()) {
            File root = Environment.getExternalStorageDirectory();
            File appRoot = new File(root, "AndPermission");
            createDir(appRoot);

            if (TextUtils.isEmpty(type)) {
                return appRoot;
            }

            File dir = new File(appRoot, type);
            createDir(dir);

            return dir;
        }
        throw new RuntimeException("External storage device is not available.");
    }

    public static String getDataDir(Context context) {
        /* On API 4 and later, you can just do this */
        // return context.getApplicationInfo().dataDir;

        String packageName = context.getPackageName();
        PackageManager pm = context.getPackageManager();
        String dataDir = null;
        try {
            dataDir = pm.getApplicationInfo(packageName, 0).dataDir;
        } catch (Exception e) {
            // Won't happen -- we know we're installed
        }
        return dataDir;
    }

	public static File getSupportDir(Context c) {
        return new File(getDataDir(c) + "/support/");
    }

	public File getInstallDir(Context context) {
        try {
            return new File(context.getPackageManager().getApplicationInfo(context.getPackageName(), 0).dataDir);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    public static File getSdcardInstallDir() {
        return new File(FolderMe.EXTERNAL_DIR + "/Debian");
    }
    public static void createDir(File dir) {
        if (dir.exists()) {
            if (!dir.isDirectory()) {
                dir.delete();
            }
        }
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }


    public interface OnFolderMeListener {
        void onSuccess(String path);
        void onFailed(String message);
    }
}
