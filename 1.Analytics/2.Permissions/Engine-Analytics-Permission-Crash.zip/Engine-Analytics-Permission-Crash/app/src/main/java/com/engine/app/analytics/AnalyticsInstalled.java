package com.engine.app.analytics;


import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.List;

public class AnalyticsInstalled {

	public static final String getGooglePlay(String appId) {
		return "https://play.google.com/store/apps/details?id=" + appId;
	}
    public static final String FACEBOOK = "com.facebook.katana";
    public static final String FACEBOOK_MESSENGER = "com.facebook.orca";
    public static final String FACEBOOK_LITE = "com.facebook.lite";
    public static final String FACEBOOK_MENTIONS = "com.facebook.Mentions";
    public static final String FACEBOOK_GROUPS = "com.facebook.groups";
    public static final String FACEBOOK_PAGES_MANAGER = "com.facebook.pages.app";
    public static final String MSQRD = "me.msqrd.android";
    public static final String WHATSAPP = "com.whatsapp";
    public static final String VIBER = "com.viber.voip";
    public static final String TELEGRAM = "org.telegram.messenger";
    public static final String GOOGLE = "com.google.android.googlequicksearchbox";
    public static final String CHROME = "com.android.chrome";
    public static final String GOOGLE_DRIVE = "com.google.android.apps.docs";
    public static final String GOOGLE_TRANSLATE = "com.google.android.apps.translate";
    public static final String GOOGLE_CALENDAR = "com.google.android.calendar";
    public static final String GMAIL = "com.google.android.gm";
    public static final String YOUTUBE = "com.google.android.youtube";
    public static final String GOOGLE_MAPS = "com.google.android.apps.maps";
    public static final String GOOGLE_DOCS = "com.google.android.apps.docs.editors.docs";
    public static final String GOOGLE_SHEETS = "com.google.android.apps.docs.editors.sheets";
    public static final String HANGOUTS = "com.google.android.talk";
    public static final String GOOGLE_ALLO = "com.google.android.apps.fireball";
    public static final String CLEAN_MASTER = "com.cleanmaster.mguard";
    public static final String UBER = "com.ubercab";
    public static final String LYFT = "me.lyft.android";
    public static final String DUBSMASH = "com.mobilemotion.dubsmash";
    public static final String SNAPCHAT = "com.snapchat.android";
    public static final String NETFLIX = "com.netflix.mediaclient";
    public static final String QUORA = "com.quora.android";
    public static final String LINKEDIN = "com.linkedin.android";
    public static final String PINTEREST = "com.pinterest";
    public static final String TUMBLR = "com.tumblr";

    public static boolean isIntalled(Context context, String packageName) {
        boolean exist = false;
        PackageManager pm = context.getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolveInfoList = pm.queryIntentActivities(intent, 0);
        for (ResolveInfo resolveInfo : resolveInfoList) {
            if (resolveInfo.activityInfo.packageName.equals(packageName)) {
                exist = true;
            }
        }
        return exist;
    }

}
