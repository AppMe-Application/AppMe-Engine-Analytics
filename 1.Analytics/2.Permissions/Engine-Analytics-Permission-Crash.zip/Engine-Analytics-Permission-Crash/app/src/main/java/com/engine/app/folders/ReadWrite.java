package com.engine.app.folders;

import android.app.AlertDialog;
import android.support.v4.provider.DocumentFile;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.text.Spanned;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.BackgroundColorSpan;
import android.util.Log;
import android.widget.TextView;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.LineIterator;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.DataInputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Locale;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.nio.charset.Charset;

import com.engine.R;
import android.webkit.MimeTypeMap;

public class ReadWrite {


    private static final String TAG = ReadWrite.class.getSimpleName();
    private Context context;
    private SharedPreferences mSharedPref;
    private final String APP_PREF_NAME = "app_settings";

    private static volatile List<String> protocol = new ArrayList<>();
    private static char lastChar = '\n';
    private static String lastLine = "";
    private String FILE_NAME = "";
    private String FILE_PATH = FolderMe.FOLDER_SCRIPTME_PROJECTS;

    private OnWriteFileListener mOnReadWriteListener;
    private OnReadFileListener mOnReadFileListener;
    private String text = "";
	private boolean append = false;
	
    private ReadWrite(Context context) {
        this.context = context;
        mSharedPref = context.getSharedPreferences(APP_PREF_NAME, Context.MODE_PRIVATE);

    }

    public static ReadWrite with(Context context) {
        return new ReadWrite(context);
    }

    public ReadWrite setFile(String filePath, String fileName) {
        this.FILE_PATH = filePath;
        this.FILE_NAME = fileName;
        return this;
    }
	
	public ReadWrite setAppend(boolean append) {
        SharedPreferences.Editor e = mSharedPref.edit();
        e.putBoolean("read_write_append", append);
        e.apply();
        return this;
    }
	
    public ReadWrite write(String text, OnWriteFileListener mOnReadWriteListener) {
        SharedPreferences.Editor e = mSharedPref.edit();
        e.putBoolean("read_write", true);
        e.apply();
        this.text = text;
        this.mOnReadWriteListener = mOnReadWriteListener;
        return this;
    }

    public ReadWrite read(final OnReadFileListener mOnReadFileListener) {
        SharedPreferences.Editor e = mSharedPref.edit();
        e.putBoolean("read_write", false);
        e.apply();
        this.mOnReadFileListener = mOnReadFileListener;        
        return this;
    }

    public void start() {
        boolean isReadWrite = mSharedPref.getBoolean("read_write", true);
        if (isReadWrite) {
            appendMessage(text);           
        } else {
            final String file = FILE_PATH + "/" + FILE_NAME;     
            if (FolderMe.externalAvailable()) {

                new AsyncTask<String, Void, String>() {
                    @Override
                    protected void onPreExecute() {
                        String message = "Read File Starting..";
                        if (mOnReadFileListener != null) {
                            mOnReadFileListener.onStart(message);
                        }
                    }

                    @Override
                    protected String doInBackground(String... files) {
                        String result = null;
                        StringBuffer sb = new StringBuffer();
                        if (!isFileExits(files[0])) {
                            return sb.toString();
                        }

                        try {
                            //get the file object
                            File file = FileUtils.getFile(files[0]);

                            //get the temp directory
                            File tempDir = FileUtils.getTempDirectory();

                            System.out.println(tempDir.getName());

                            //copy file to temp directory
                            FileUtils.copyFileToDirectory(file, tempDir);

                            //create a new file
                            File newTempFile = FileUtils.getFile(tempDir, file.getName());

                            //get the content
                            String data = FileUtils.readFileToString(newTempFile, Charset.defaultCharset());

                            //print the content
                            System.out.println(data);
                            sb.append(data);

                            result = sb.toString();

                        } catch (IOException e) {
                            if (mOnReadFileListener != null) {
                                mOnReadFileListener.onFailed(e.getMessage());
                            }
                            Log.e(getClass().getSimpleName(), "Exception reading file", e);
                        }


                        return result;
                    }

                    @Override
                    protected void onPostExecute(String result) {                
                        final StringBuilder sb = new StringBuilder();  
                        String textResult = result;
                        if (result.length() < 1) {
                            sb.append("<Empty>");
                            textResult = "<Empty>"; 
                        } else {
                            textResult = result;
                        }   
                        if (mOnReadFileListener != null) {
                            mOnReadFileListener.onComplete(file, textResult);
                        }  
                    }   
                }.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, file);
            } else {
                String msg = "External storage device is not available.";
                if (mOnReadFileListener != null) {
                    mOnReadFileListener.onFailed(msg);
                }
            }
        } 
    }

    /**
     * Generate timestamp
     *
     * @return timestamp
     */
    private static String getTimeStamp() {
        return "[" + new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH).format(new Date()) + "] ";
    }

    /**
     * Append the message to protocol and show
     *
     * @param c   context
     * @param msg message
     */
    private synchronized void appendMessage(final String msg) {	
        if (msg.length() == 0) return;
        String out = msg;
        boolean timestamp = mSharedPref.getBoolean("timestamp", context.getString(R.string.pref_time_stamp).equals("true"));
        int maxLines = getMaxLines();
        int protocolSize = protocol.size();
        if (protocolSize > 0 && lastChar != '\n') {
            protocol.remove(protocolSize - 1);
            out = lastLine + out;
        }
        lastChar = out.charAt(out.length() - 1);
        String[] lines = out.split("\\n");
        for (int i = 0, l = lines.length; i < l; i++) {
            lastLine = lines[i];
            if (timestamp) protocol.add(getTimeStamp() + lastLine);
            else protocol.add(lastLine);
            if (protocolSize + i >= maxLines) {
                protocol.remove(0);
            }
        }

        // write log
        String file = FILE_PATH + "/" + FILE_NAME;    
        if (FolderMe.externalAvailable())            
            writeText(file, TextUtils.join("\n", protocol));
    }

    /**
     * Get protocol
     *
     * @return protocol as text
     */
    public static String get() {
        return android.text.TextUtils.join("\n", protocol);
    }

    /**
     * Clear protocol
     */
    public static void clear() {
        protocol.clear();
    }

    /**
     * Write to log file
     *
     * @param c   context
     * @param msg message
     */
    private void writeText(String filePath, String content) {
		boolean isAppend = mSharedPref.getBoolean("read_write_append", false);
		
        try {
            File f = new File(filePath);
            f.getParentFile().mkdirs();
            if (!f.exists()) {
                try {
                    f.createNewFile();                    
                } catch (IOException io) {
                    io.getMessage();
                }
            }

            FileUtils.writeStringToFile(f, content, isAppend);
            if (mOnReadWriteListener != null) {
                mOnReadWriteListener.onSuccess(f.getAbsolutePath(), content);
            }    
        } catch (IOException e) {
            if (mOnReadWriteListener != null) {
                mOnReadWriteListener.onFailed(e.getMessage());
            }
        } 
    }
  
    public static void deleteTarget(String path) {
        File target = new File(path);

        if (target.isFile() && target.canWrite()) {
            target.delete();
        } else if (target.isDirectory() && target.canRead() && target.canWrite()) {
            String[] file_list = target.list();

            if (file_list != null && file_list.length == 0) {
                target.delete();
                return;
            } else if (file_list != null && file_list.length > 0) {
                for (String aFile_list : file_list) {
                    File temp_f = new File(target.getAbsolutePath() + "/"
                                           + aFile_list);

                    if (temp_f.isDirectory())
                        deleteTarget(temp_f.getAbsolutePath());
                    else if (temp_f.isFile()) {
                        temp_f.delete();
                    }
                }
            }

            if (target.exists())
                target.delete();
        } 
    }

    public static void writeFile(String path, String content, boolean append) {
        try {
            File f = new File(path);
            if (!f.getParentFile().exists()) {
                f.getParentFile().mkdirs();
            }
            if (!f.exists()) {
                f.createNewFile();
                f = new File(path); // 重新实例化
            }
            FileWriter fw = new FileWriter(f, append);
            if ((content != null) && !"".equals(content)) {
                fw.write(content);
                fw.flush();
            }
            fw.close();

        } catch (Exception e) {
            e.printStackTrace();            
        }
    }

    public static void writeFileToJson(String path, String content) {
        try {
            File f = new File(path);
            if (!f.getParentFile().exists()) {
                f.getParentFile().mkdirs();
            }
            if (!f.exists()) {
                f.createNewFile();
                f = new File(path); // 重新实例化
            }

            JSONObject json = new JSONObject();
            json.put("content", content);

            FileUtils.writeStringToFile(f, json.toString());
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    public static void saveStreamToFile(InputStream in, String fileName) {
        int size;
        byte[] buffer = new byte[1000];
        BufferedOutputStream bufferedOutputStream = null;
        try {
            bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
            while ((size = in.read(buffer)) > -1) {
                bufferedOutputStream.write(buffer, 0, size);
            }
            bufferedOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 读取文件内容
     * 
     * @param path
     * @return String
     */
    public static String readText(String filePath) {
        StringBuffer sb = new StringBuffer();
        if (!isFileExits(filePath)) {
            return sb.toString();
        }

        try {
            //get the file object
            File file = FileUtils.getFile(filePath);

            //get the temp directory
            File tempDir = FileUtils.getTempDirectory();

            System.out.println(tempDir.getName());

            //copy file to temp directory
            FileUtils.copyFileToDirectory(file, tempDir);

            //create a new file
            File newTempFile = FileUtils.getFile(tempDir, file.getName());

            //get the content
            String data = FileUtils.readFileToString(newTempFile, Charset.defaultCharset());

            //print the content
            System.out.println(data);
            sb.append(data);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    public static String readTextFromJson(String textJson) {
        try {
            File textFile = new File(textJson);
            JSONObject json = new JSONObject(FileUtils.readFileToString(textFile));
            return json.getString("content");
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    public static FileFilter imagefileFilter = new FileFilter() {
        @Override
        public boolean accept(File pathname) {
            String tmp = pathname.getName().toLowerCase();
            if (tmp.endsWith(".png") || tmp.endsWith(".jpg") || tmp.endsWith(".bmp") || tmp.endsWith(".gif") || tmp.endsWith(".jpeg")) {
                return true;
            }
            return false;
        }
    };

    /**
     * 文件夹过滤器
     */
    public static FileFilter folderFilter = new FileFilter() {
        @Override
        public boolean accept(File pathname) {
            return pathname.isDirectory();
        }
    };

    /**
     * 铃声文件过滤器
     */
    public static FileFilter mp3fileFilter = new FileFilter() {
        @Override
        public boolean accept(File pathname) {
            String tmp = pathname.getName().toLowerCase();
            if (tmp.endsWith(".mp3") || tmp.endsWith(".ogg") || tmp.endsWith(".wav")) {
                return true;
            }
            return false;
        }
    };

    public static File[] getFilesFromDir(String dirPath, FileFilter fileFilter) {
        File dir = new File(dirPath);
        if (dir.isDirectory()) {
            if (fileFilter != null)
                return dir.listFiles(fileFilter);
            else
                return dir.listFiles();
        }
        return null;
    }

    /**
     * 获取已存在的文件名列表
     * @param dir 目录
     * @param fileFilter 过滤器
     * @param hasSuffix 是否包括后缀
     * @return List<String>
     */
    public static List<String> getExistsFileNames(String dir, FileFilter fileFilter, boolean hasSuffix) {
        String path = dir;
        File file = new File(path);
        File[] files = file.listFiles(fileFilter);
        List<String> fileNameList = new ArrayList<String>();
        if (null != files) {
            for (File tmpFile : files) {
                String tmppath = tmpFile.getAbsolutePath();
                String fileName = getFileName(tmppath, hasSuffix);
                fileNameList.add(fileName);
            }
        }
        return fileNameList;
    }

    /**
     * 获取已存在的文件名列表 (包括子目录)
     * @param dir 目录
     * @param hasSuffix 是否包括后缀
     * @return List<String>
     */
    public static List<String> getAllExistsFileNames(String dir, boolean hasSuffix) {
        String path = dir;
        File file = new File(path);
        File[] files = file.listFiles();
        List<String> fileNameList = new ArrayList<String>();
        if (null != files) {
            for (File tmpFile : files) {
                if (tmpFile.isDirectory()) {
                    fileNameList.addAll(getAllExistsFileNames(tmpFile.getPath(), hasSuffix));
                } else {
                    String tmp = tmpFile.getName().toLowerCase();
                    if (tmp.endsWith(".png") || tmp.endsWith(".jpg") || tmp.endsWith(".bmp") || tmp.endsWith(".gif") || tmp.endsWith(".jpeg")) {
                        fileNameList.add(tmpFile.getAbsolutePath());
                    }
                }
            }
        }
        return fileNameList;
    }

    public static String getFileName(String path, boolean hasSuffix) {
        if (null == path || -1 == path.lastIndexOf("/") || -1 == path.lastIndexOf("."))
            return null;
        if (!hasSuffix)
            return path.substring(path.lastIndexOf("/") + 1, path.lastIndexOf("."));
        else
            return path.substring(path.lastIndexOf("/") + 1);
    }

    public static String getPath(String path) {
        File file = new File(path);
        try {
            if (!file.exists() || !file.isDirectory())
                file.mkdirs();
            return file.getAbsolutePath();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean isFileExits(String dir, String fileName) {
        fileName = fileName == null ? "" : fileName;
        dir = dir == null ? "" : dir;
        int index = dir.lastIndexOf("/");
        String filePath;
        if (index == dir.length() - 1)
            filePath = dir + fileName;
        else
            filePath = dir + "/" + fileName;
        File file = new File(filePath);
        return file.exists();
    }

    public static boolean isFileExits(String filePath) {
        try {
            File file = new File(filePath);
            if (file.exists())
                return true;
        } catch (Exception e) {

        }
        return false;
	}

    public static void searchFor(String text, TextView prose) {
        Spannable raw = new SpannableString(prose.getText());
        BackgroundColorSpan[] spans = raw.getSpans(0, raw.length(), BackgroundColorSpan.class);
                                                                                                              
        for (BackgroundColorSpan span : spans) {
            raw.removeSpan(span);
        }

        int index = TextUtils.indexOf(raw, text);

        while (index >= 0) {
            raw.setSpan(new BackgroundColorSpan(0xFF8B008B), index, index + text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);                        
            index = TextUtils.indexOf(raw, text, index + text.length());
        }

        prose.setText(raw);        
     }
     
    public static Intent createFileOpenIntent(File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);     
        intent.setDataAndType(Uri.fromFile(file), MimeTypeMap.getFileExtensionFromUrl(file.getAbsolutePath()));
        return intent;
    }

    public static void openFile(final Context c, final File file) {
        if (file.isDirectory())
            throw new IllegalArgumentException("File cannot be a directory!");

        Intent intent = createFileOpenIntent(file);

        try {
            c.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            c.startActivity(Intent.createChooser(intent, c.getString(R.string.action_open_with, file.getName())));
        } catch (Exception e) {
            new AlertDialog.Builder(c)
                .setMessage(e.getMessage())
                .setTitle(R.string.action_open_cant_openfile)
                .setPositiveButton(android.R.string.ok, null)
                .show();
        }

    }

    public int getMaxLines() {
        int maxLinesInt;
        String maxLines = mSharedPref.getString("maxlines", context.getString(R.string.pref_maxlines));
        try {
            maxLinesInt = Integer.parseInt(maxLines);
        } catch (Exception e) {
            maxLines = context.getString(R.string.pref_maxlines);
            maxLinesInt = Integer.parseInt(maxLines);
            SharedPreferences.Editor editor = mSharedPref.edit();
            editor.putString("maxlines", maxLines);
            editor.apply();
        }
        return maxLinesInt;
    }

    public interface OnWriteFileListener {
        void onSuccess(String filePath, String text);
        void onFailed(String message);
    }

    public interface OnReadFileListener {
        void onStart(String message);
        void onComplete(String filePath, final String message);
        void onFailed(String message);
    }
}
