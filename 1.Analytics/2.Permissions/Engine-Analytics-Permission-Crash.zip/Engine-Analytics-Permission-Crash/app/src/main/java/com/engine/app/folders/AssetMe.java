package com.engine.app.folders;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Handler;
import android.os.Message;
import android.os.Looper;
import android.util.Log;
import android.text.TextUtils;
import android.preference.PreferenceManager;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.lang.ref.WeakReference;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.engine.app.folders.archiver.Un7Zip;
import com.engine.app.folders.archiver.callback.IExtractCallback;
import com.engine.app.folders.archiver.callback.ExtractCallback;


public class AssetMe {

    private static final String TAG = AssetMe.class.getSimpleName();
	
	private Activity mActivity;
	private Context context;
	private String mOutputPath;
    private String mInputFilePath;
    private ProgressDialog mProgressDialog;
    private ExecutorService mExecutor;
	private static final int MSG_COPY_SUCCESS = 100;
    private static final int MSG_COPY_FAILED = 101;
    private OnAssetsManagerListener mOnAssetsManagerListener;
    private String fullPath;
    
    public static String getFilesDirectory(Context context) {
        // creates files directory under data/data/package name
        return context.getExternalFilesDir("sound").getAbsolutePath();
	}
	
    public static final long DEFAULT_IN_BUF_SIZE = 0x200000;
    public static final int SZ_OK = 0;

    public static final int SZ_ERROR_DATA = 1;
    public static final int SZ_ERROR_MEM = 2;
    public static final int SZ_ERROR_CRC = 3;
    public static final int SZ_ERROR_UNSUPPORTED = 4;
    public static final int SZ_ERROR_PARAM = 5;
    public static final int SZ_ERROR_INPUT_EOF = 6;
    public static final int SZ_ERROR_OUTPUT_EOF = 7;
    public static final int SZ_ERROR_READ = 8;
    public static final int SZ_ERROR_WRITE = 9;
    public static final int SZ_ERROR_PROGRESS = 10;
    public static final int SZ_ERROR_FAIL = 11;
    public static final int SZ_ERROR_THREAD = 12;

    public static final int SZ_ERROR_ARCHIVE = 16;
    public static final int SZ_ERROR_NO_ARCHIVE = 17;

    public static final int ERROR_CODE_PATH_ERROR = 999;

    private AssetMe(Context context) {
        this.context = context;
		this.mActivity = (Activity)context;
		mProgressDialog = new ProgressDialog(context);
        mExecutor = Executors.newSingleThreadExecutor();
        
        File outFile = context.getExternalFilesDir("extracted");
        if (outFile == null || !outFile.exists()) {
            outFile = context.getFilesDir();
        }
		mOutputPath = outFile.getPath();
    }

    public static AssetMe with(Context context) {
        return new AssetMe(context);
    }
	
	public AssetMe extract() {
        // prepare env directory
        String envDir = context.getExternalFilesDir(null).getAbsolutePath();
        File fEnvDir = new File(envDir);
        if (!fEnvDir.exists()) {
            fEnvDir.mkdirs();          
        }
        cleanDirectory(fEnvDir);

        // extract assets
        if (!extractDir(context, "system", "")) {
            mHandler.obtainMessage(MSG_COPY_FAILED).sendToTarget();
        } else {
            mHandler.obtainMessage(MSG_COPY_SUCCESS).sendToTarget();
        }


        return this;
    }
	
	public void getAssetMe(final String inFile, final String outFile, final OnAssetMeListener listener) {
        mExecutor.submit(new Runnable(){
				@Override
				public void run() {
					SoundFile.getInstance().getSoundAdd();
					listener.onStart();
					Un7Zip.extractAsset(context.getAssets(), inFile, outFile, new ExtractCallback() {
							@Override
							public void onStart() {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {										
											if(listener != null){
												listener.onStart();	
											}
										}
									});
							}
								
							@Override
							public void onProgress(final String name, final long size) {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											if(listener != null){
												listener.onProgress(name, size);	
											}
										}
									});
							}

							@Override
							public void onError(final int errorCode, final String message) {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											if(listener != null){
											listener.onError(errorCode, message);	
											}
											mExecutor.shutdownNow();
											SoundFile.getInstance().getSoundError();
										}
									});
							}

							@Override
							public void onSucceed() {
								mActivity.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											if(listener != null){
												listener.onSucceed();	
											}
											mExecutor.shutdownNow();
											SoundFile.getInstance().getSoundComplete();									
										}
									});
							}
						});
				}
			});
	}
    
    private void showMessage(String msg) {
        Toast.makeText(context,msg, Toast.LENGTH_SHORT).show();
    }
	
	

    public void setOnAssetsManagerListener(OnAssetsManagerListener mOnAssetsManagerListener) {
        this.mOnAssetsManagerListener = mOnAssetsManagerListener;
    }

    public interface OnAssetsManagerListener {
        void onSuccess(String path);
        void onFailed(String message);
    }

	public interface OnAssetMeListener {
		void onStart();
	
		void onProgress(String name, long size);

		void onError(int errorCode, String message);

		void onSucceed();
	}
	
    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_COPY_SUCCESS: {
                        // Toast.makeText(AppController.getContext(), "Extract Success", Toast.LENGTH_SHORT).show();
                        if (mOnAssetsManagerListener != null) {
                            mOnAssetsManagerListener.onSuccess(fullPath);
                        }
                        break;
                    }
                case MSG_COPY_FAILED: {
                        if (mOnAssetsManagerListener != null) {
                            mOnAssetsManagerListener.onFailed("File Not Found");
                        }
                        break;
                    }
            }
        }
    };
    /**
     * Closeable helper
     *
     * @param c closable object
     */
    private static void close(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Extract file to env directory
     *
     * @param c         context
     * @param rootAsset root asset name
     * @param path      path to asset file
     * @return false if error
     */
    public boolean extractFile(Context c, String rootAsset, String path) {
        AssetManager assetManager = c.getAssets();
        InputStream in = null;
        OutputStream out = null;
        try {
            in = assetManager.open(rootAsset + path);
            fullPath = c.getExternalFilesDir(null) + path;
            out = new FileOutputStream(fullPath);
            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            close(in);
            close(out);
        }
        return true;
    }

    /**
     * Extract path to env directory
     *
     * @param c         context
     * @param rootAsset root asset name
     * @param path      path to asset directory
     * @return false if error
     */
    public boolean extractDir(Context c, String rootAsset, String path) {
        AssetManager assetManager = c.getAssets();
        try {
            String[] assets = assetManager.list(rootAsset + path);
            if (assets.length == 0) {
                if (!extractFile(c, rootAsset, path)) return false;
            } else {
                String fullPath = c.getExternalFilesDir(null) + path;
                File dir = new File(fullPath);
                if (!dir.exists()) dir.mkdir();
                for (String asset : assets) {
                    if (!extractDir(c, rootAsset, path + "/" + asset)) return false;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static void extraRawFile(Context context, int resId, Handler handler) {

        String folderPath = context.getExternalFilesDir("web").getAbsolutePath() + "/";
        InputStream is = context.getResources().openRawResource(resId);
        if (unzip(is, folderPath, handler)) {
            String md5 = getFileMd5(context, resId);
            AssetMe.setFileMd5Preference(context, md5);
        }
    }

    /**
     * Recursive remove all from directory
     *
     * @param path path to directory
     */
    public static void cleanDirectory(File path) {
        if (path == null) return;
        if (path.exists()) {
            File[] list = path.listFiles();
            if (list == null) return;
            for (File f : list) {
                if (f.isDirectory()) cleanDirectory(f);
                f.delete();
            }
        }
    }

    /**
     * Recursive set permissions to directory
     *
     * @param path path to directory
     */
    public static void setPermissions(File path) {
        if (path == null) return;
        if (path.exists()) {
            path.setReadable(true, false);
            path.setExecutable(true, false);
            File[] list = path.listFiles();
            if (list == null) return;
            for (File f : list) {
                if (f.isDirectory()) setPermissions(f);
                f.setReadable(true, false);
                f.setExecutable(true, false);
            }
        }
    }

    public static boolean remove(Context c, String path) {
        File fEnvDir = new File(c.getExternalFilesDir(path).getAbsolutePath());
        if (!fEnvDir.exists()) {
            return false;
        }
        cleanDirectory(fEnvDir);
        return true;
    }
    /**
     * Update env directory
     *
     * @param c context
     * @return false if error
     */
    public boolean update() {
        try {
            // prepare env directory
            String envDir = context.getExternalFilesDir(null).getAbsolutePath();
            File fEnvDir = new File(envDir);
            fEnvDir.mkdirs();
            if (!fEnvDir.exists()) {

            }
            cleanDirectory(fEnvDir);

            // extract assets
            if (!extractDir(context, "system", "")) {

            }

            // set executable app directory
            File appDir = new File(fEnvDir + "/..");
            appDir.setExecutable(true, false);

            // set permissions
            setPermissions(fEnvDir);
            return true;
        } catch (Exception e) {
            e.printStackTrace();            
        }
        return false;
    }

    public static boolean isUpdate(String filePath, String fileName) {
        File file = new File(filePath, fileName);
        Log.d(TAG, "check file dir " + file.getAbsolutePath() + ",exist=" + file.exists());        
        return !file.exists();
    }

    public static boolean isUpdate(Context context, String filePath, String fileName, int resId) {
        File file = new File(filePath, fileName);
        Log.d(TAG, "check file dir " + file.getAbsolutePath() + ",exist=" + file.exists());
        if (!file.exists()) {
            return false;
        }   
        String md5 = getFileMd5(context, resId);
        return getFileMd5Preference(context).equals(md5);
    }

    private static String getFileMd5(Context context, int resId) {

        MessageDigest digest = null;
        InputStream in = context.getResources().openRawResource(resId);
        byte buffer[] = new byte[1024];
        int len;
        try {
            digest = MessageDigest.getInstance("MD5");
            while ((len = in.read(buffer, 0, 1024)) != -1) {
                digest.update(buffer, 0, len);
            }
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        BigInteger bigInt = new BigInteger(1, digest.digest());
        return bigInt.toString(16);

    }

    public static String getFileMd5Preference(Context context) {
        SharedPreferences sp = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);       
        return sp.getString("file_md5", "");
    }

    public static void setFileMd5Preference(Context context, String md5) {
        SharedPreferences sp = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("file_md5", md5).commit();
        editor.commit();      
    }

    /**
     * 指定目录下是否存在指定名称的文件
     * @param dir 目录
     * @param fileName 文件名称
     * @return boolean
     */
    public static boolean isFileExits(String dir, String fileName) {
        fileName = fileName == null ? "" : fileName;
        dir = dir == null ? "" : dir;
        int index = dir.lastIndexOf("/");
        String filePath;
        if (index == dir.length() - 1)
            filePath = dir + fileName;
        else
            filePath = dir + "/" + fileName;
        File file = new File(filePath);
        return file.exists();
    }

    /**
     * 指定路么下是否存在文件
     * @param filePath 文件路径
     * @return boolean
     */
    public static boolean isFileExits(String filePath) {
        try {
            File file = new File(filePath);
            if (file.exists())
                return true;
        } catch (Exception e) {

        }
        return false;
	}

    private static boolean unzip(InputStream zipFileName, String outputDirectory,
                                 Handler handler) {
        try {
            ZipInputStream in = new ZipInputStream(zipFileName);

            ZipEntry entry = in.getNextEntry();
            while (entry != null) {

                File file = new File(outputDirectory);
                if (!file.exists()) {
                    file.mkdir();
                }

                if (entry.isDirectory()) {
                    String name = entry.getName();
                    name = name.substring(0, name.length() - 1);

                    file = new File(outputDirectory + File.separator + name);
                    file.mkdir();

                } else {
                    file = new File(outputDirectory + File.separator
                                    + entry.getName());
                    file.createNewFile();
                    FileOutputStream out = new FileOutputStream(file);
                    int b;
                    while ((b = in.read()) != -1) {
                        out.write(b);
                    }
                    out.close();
                }
                entry = in.getNextEntry();
            }
            in.close();


            Message msg = new Message();
            msg.what = 0;
            handler.sendMessage(msg);
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Message msg = new Message();
            msg.what = 1;
            handler.sendMessage(msg);
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            Message msg = new Message();
            msg.what = 1;
            handler.sendMessage(msg);
            return false;
        }
    }
	
}
