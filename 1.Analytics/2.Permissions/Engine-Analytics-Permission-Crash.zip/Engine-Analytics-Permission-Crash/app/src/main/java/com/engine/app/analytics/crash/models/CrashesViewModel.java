package com.engine.app.analytics.crash.models;

import com.engine.app.analytics.crash.investigation.CrashViewModel;
import com.engine.app.analytics.crash.investigation.ViewState;

import java.util.List;

public class CrashesViewModel {
  private final List<CrashViewModel> crashViewModels;

  public CrashesViewModel(List<CrashViewModel> crashViewModels) {
    this.crashViewModels = crashViewModels;
  }

  public List<CrashViewModel> getCrashViewModels() {
    return crashViewModels;
  }

  public ViewState getCrashNotFoundViewState() {
    return new ViewState.Builder().withVisible(crashViewModels.isEmpty()).build();
  }
}
