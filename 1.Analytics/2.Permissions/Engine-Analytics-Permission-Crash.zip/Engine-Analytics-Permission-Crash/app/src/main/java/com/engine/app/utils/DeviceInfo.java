package com.engine.app.utils;

import android.content.Context;
import android.os.Build;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;


public class DeviceInfo {
    private static volatile DeviceInfo Instance = null;
    private static String LINE_SEPARATOR = "\n";
    private Context mContext;
	
	private DeviceInfo(Context context){
		this.mContext = context;
	}
    public static DeviceInfo with(Context context) {      
        return new DeviceInfo(context);
    }
    
    public void getDeviceInfo() {
        StringBuilder deviceInfo = new StringBuilder();
        try {

            deviceInfo.append("\n************ DEVICE INFORMATION ***********\n");
            deviceInfo.append("Brand: ");
            deviceInfo.append(Build.BRAND);
            deviceInfo.append(LINE_SEPARATOR);
            deviceInfo.append("Device: ");
            deviceInfo.append(Build.DEVICE);
            deviceInfo.append(LINE_SEPARATOR);
            deviceInfo.append("Model: ");
            deviceInfo.append(Build.MODEL);
            deviceInfo.append(LINE_SEPARATOR);
            deviceInfo.append("Id: ");
            deviceInfo.append(Build.ID);
            deviceInfo.append(LINE_SEPARATOR);
            deviceInfo.append("Product: ");
            deviceInfo.append(Build.PRODUCT);
            deviceInfo.append(LINE_SEPARATOR);
            deviceInfo.append("\n************ FIRMWARE ************\n");
            deviceInfo.append("SDK: ");
            deviceInfo.append(Build.VERSION.SDK_INT);
            deviceInfo.append(LINE_SEPARATOR);
            deviceInfo.append("Release: ");
            deviceInfo.append(Build.VERSION.RELEASE);
            deviceInfo.append(LINE_SEPARATOR);
            deviceInfo.append("Incremental: ");
            deviceInfo.append(Build.VERSION.INCREMENTAL);
            deviceInfo.append(LINE_SEPARATOR);
            File log = new File(mContext.getExternalFilesDir("log"), "devive-info.log");
            log.getParentFile().mkdirs();
            FileUtils.writeStringToFile(log, deviceInfo.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    } 
}
