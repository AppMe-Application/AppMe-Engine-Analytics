package com.engine.app.analytics.crash.presenter;

import com.engine.app.analytics.crash.database.CrashDatabaseHelper;
import com.engine.app.analytics.crash.investigation.Crash;
import com.engine.app.analytics.crash.investigation.CrashViewModel;
import com.engine.app.analytics.crash.models.CrashesViewModel;
import com.engine.app.analytics.crash.listeners.OnCrashActionListener;

import java.util.ArrayList;
import java.util.List;

public class CrashListPresenter {
    private final OnCrashActionListener mOnCrashActionListener;

    public CrashListPresenter(OnCrashActionListener onCrashActionListener) {
        this.mOnCrashActionListener = onCrashActionListener;
    }

    public void render(CrashDatabaseHelper database) {
        List<Crash> crashes = database.getCrashes();
        ArrayList<CrashViewModel> crashViewModels = new ArrayList<>();
        for (Crash crash : crashes) {
            crashViewModels.add(new CrashViewModel(crash));
        }
        mOnCrashActionListener.render(new CrashesViewModel(crashViewModels));
    }

    public void onCrashClicked(CrashViewModel viewModel) {
        mOnCrashActionListener.openCrashDetails(viewModel.getIdentifier());
    }
}
