package com.engine.app.analytics.version.models;

import android.content.Context;
import org.json.JSONObject;

import java.net.URL;

import com.engine.app.analytics.version.utils.UpdateUtils;
import com.engine.app.utils.AppUtils;

public class UpdateModel {
    int versionCode;
    boolean cancellable;
    String url;

    public UpdateModel(int versionCode, boolean cancellable, String url) {
        this.versionCode = versionCode;
        this.cancellable = cancellable;
        this.url = url;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public int getLatestCode(){
        return AppUtils.getAppVersionCode();
    }
    
    public URL getLatestApkUrl(JSONObject json) throws Exception {
        String apkUrl = json.getString("url");
        return new URL(apkUrl);
	}
    
    public boolean isCancellable() {
        return cancellable;
    }

    public void setCancellable(boolean cancellable) {
        this.cancellable = cancellable;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
