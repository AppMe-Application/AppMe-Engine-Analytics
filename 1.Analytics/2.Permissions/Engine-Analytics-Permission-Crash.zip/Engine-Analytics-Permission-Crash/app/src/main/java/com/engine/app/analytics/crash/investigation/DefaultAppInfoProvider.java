package com.engine.app.analytics.crash.investigation;

import android.content.Context;

import com.engine.app.analytics.crash.investigation.AppInfo;

public class DefaultAppInfoProvider implements AppInfoProvider {
  private final Context context;

  public DefaultAppInfoProvider(Context context) {
    this.context = context;
  }

  @Override
  public AppInfo getAppInfo() {
    return new AppInfo.Builder()
        .with("Version", AppInfo.getAppVersion(context))
        .build();
  }
}
