package com.engine.app.analytics.version;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

import com.engine.R;
import com.engine.app.analytics.version.VersionChecker;
import com.engine.app.analytics.version.models.UpdateModel;
import com.engine.app.analytics.version.utils.UpdateUtils;
import com.engine.app.analytics.version.listeners.UpdateListener;
import com.engine.app.analytics.version.tasks.VersionCheckerTask;

public class VersionChecker {
    
    public static final String TAG = VersionChecker.class.getSimpleName();
	
    private static volatile VersionChecker Instance = null;
    private Context mContext;
    private boolean updatesAvailable = false;
    private OnUpdateVersionListener mOnUpdateVersionListener;
    public static VersionChecker getInstance() {
        VersionChecker localInstance = Instance;
        if (localInstance == null) {
            synchronized (VersionChecker.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new VersionChecker();
                }
            }
        }
        return localInstance;
    }
    
    private VersionChecker(){}
	private VersionChecker(Context context){
		this.mContext = context;
	}
	
    public static VersionChecker with(Context context) {      
        return new VersionChecker(context);
    }
	
    public boolean checkForUpdates(final Context c){      
        new VersionCheckerTask(c, "https://raw.githubusercontent.com/AsepMo/Android-Template-Evolution/main/Application/json/updater.json", new UpdateListener() {
                @Override
                public void onJsonDataReceived(final UpdateModel updateModel, JSONObject jsonObject) {
                    if (VersionCheckerTask.getCurrentVersionCode(c) < updateModel.getVersionCode()) {
                        updatesAvailable = true;
                        Log.d(TAG, "Update available.  APK_URL: " + updateModel.getVersionCode());
                    }else{
                        updatesAvailable = false;
                    }
                }

                @Override
                public void onError(String error) {
                    // Do something

                }
			}).execute();
        return updatesAvailable;
    }
    
    public void getUpdateVersion(){
        new VersionCheckerTask(mContext, "https://raw.githubusercontent.com/AsepMo/Android-Template-Evolution/main/Application/json/updater.json", new UpdateListener() {
                @Override
                public void onJsonDataReceived(final UpdateModel updateModel, JSONObject jsonObject) {
                    if (VersionCheckerTask.getCurrentVersionCode(mContext) < updateModel.getVersionCode()) {
                        if(mOnUpdateVersionListener != null){
                            mOnUpdateVersionListener.onUpdateVersion(updateModel);
                         }
                        Log.d(TAG, "Update available.  APK_URL: " + updateModel.getVersionCode());
                    }else{
                        
                        if(mOnUpdateVersionListener != null){
                            mOnUpdateVersionListener.onLatestVersion(updateModel);
                        }
                    }
                }

                @Override
                public void onError(String error) {
                    // Do something

                }
			}).execute();
    }
    
    public void onDialogProgress()
    {
        
    }
    
    public void setOnUpdateVersionListener(OnUpdateVersionListener listener){
        this.mOnUpdateVersionListener = listener;
    }
    
    public interface OnUpdateVersionListener
    {
        void onUpdateVersion(UpdateModel models);
        void onLatestVersion(UpdateModel models);
    }
}
