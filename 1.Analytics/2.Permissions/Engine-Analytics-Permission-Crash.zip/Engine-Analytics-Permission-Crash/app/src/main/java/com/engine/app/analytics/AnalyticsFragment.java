package com.engine.app.analytics;

import android.Manifest;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBar.OnNavigationListener;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

import com.engine.R;
import com.engine.app.fragments.UnzipFragment;
import com.engine.app.settings.Settings;
import com.engine.app.folders.FolderMe;
import com.engine.app.utils.VibrateUtils;
import com.engine.app.tasks.DefaultThreadManager;
import com.engine.app.tasks.TaskCallBack;

public class AnalyticsFragment extends Fragment {

    private static final String EXTRA_TEXT = "text";
    private AnalyticsActivity mActivity;
	private AnalyticPermissions mAnalytics;

    private Context mContext;
    private Toolbar mToolbar;
	private TextView mTextView;
    private Settings mSettings;

    public static AnalyticsFragment newInstance(String text) {
        AnalyticsFragment fragment = new AnalyticsFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_application, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        final String text = getArguments().getString(EXTRA_TEXT);
        mActivity = (AnalyticsActivity)getActivity();
        mContext = getActivity();
        mToolbar = (Toolbar) view.findViewById(R.id.toolbar);
        if (mToolbar != null) {
            mActivity.setSupportActionBar(mToolbar);
            final ActionBar actionbar = mActivity.getSupportActionBar();
            actionbar.setTitle("Home"); 
        }
	    mTextView = view.findViewById(R.id.text);
        
        mSettings = new Settings(mContext);
		mAnalytics = AnalyticPermissions.with(mContext);
		mAnalytics.requestPermission(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, new AnalyticPermissions.OnAnalyticsPermissionListener(){
				@Override
				public void onGranted(String message, List<String> permissions) {
					mActivity.runOnUiThread(new Runnable(){
							@Override
							public void run() {
								 createDir(); 
							}
						});
					
				}

				@Override
				public void onDenied(String message, List<String> permissions) {
					mActivity.showMessage("Permission Denied!");
				}
			});	
        mTextView.setText(text);
        mTextView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Toast.makeText(v.getContext(), text, Toast.LENGTH_SHORT).show();
                }
            });
    }
	
	public void createDir(){
		DefaultThreadManager.getInstance().execute(new Runnable() {
				@Override
				public void run() {
					try {
						//Thread.sleep(3000);
						mActivity.runOnUiThread(new Runnable() {
								@Override
								public void run() {
									FolderMe.with(mContext)
										.setOnFolderMeListener(new FolderMe.OnFolderMeListener(){
											@Override
											public void onSuccess(String path) {							
												showMessage("Storage Ready For Extracted!");
												VibrateUtils.vibrate(200);
											}

											@Override
											public void onFailed(String message) {
												showMessage(message);
											}
										});
								}
							});
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
	}
	
	public void showMessage(String msg) {
		Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.add("Test")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    new CountDownTimer(1000, 1000){
                        @Override
                        public void onTick(long l) {

                        }

                        @Override
                        public void onFinish() {  
                            ExampleCrashActivity.start(mActivity);
                        }
                    }.start();
                    return false;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        inflater.inflate(R.menu.menu_application, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_about:
                return true;
            case R.id.action_settings:
				mSettings.updateMedia(null, "");   
                mActivity.switchFragment(UnzipFragment.newInstance());
                return true;    
            case R.id.action_exit:
				new TaskCallBack<String,String,Boolean>(){
					@Override
					public void onPreExecute() {
						super.onPreExecute();
						showMessage("start");
						System.out.println("start ......");
					}

					@Override
					public Boolean doInBackground(String... params) {
						System.out.println("doInBackground ......");
						File file = new File(params[0]);
						return file.mkdir();
					}

					@Override
					public void onPostExecute(Boolean s) {
						super.onPostExecute(s);
						showMessage("result : " + s);
					}
				}.execute(FolderMe.EXTERNAL_DIR + "/Thread");
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}


