package com.engine;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.os.StrictMode;
import android.view.View;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.engine.app.analytics.crash.CrashTracker;
import com.engine.app.analytics.crash.CrashNotInitializedException;
import com.engine.app.analytics.crash.investigation.AppInfo;
import com.engine.app.analytics.crash.investigation.AppInfoProvider;
import com.engine.app.folders.FolderMe;
import com.engine.app.utils.Utils;
import com.engine.app.utils.LogUtils;
import com.engine.app.utils.AppUtils;
import com.engine.app.utils.ProcessUtils;
import com.engine.app.utils.CrashUtils;

public class AppController extends Application
{
    private static AppController sAppController;
    private static Context _Context;
    private Boolean isDebug;
    private Boolean isMainProcess;
	
    @Override
    public void onCreate() {
        super.onCreate();
        sAppController = this;
        _Context = this;
       	
		
        Utils.init(this);
		initConfig();
        initLog();
        initCrash();
    }

    public static synchronized AppController getInstance() {
        return sAppController;
    }
    
    public static synchronized Context getContext(){
        return _Context;
    }

	public static synchronized String getAppName() {
        return _Context.getString(R.string.app_name);
    }

    public static synchronized String getDataDir() {
        return sAppController.getDataDir();
    }

	public static synchronized String getExternalFilesDir(String dir) {
        return sAppController.getExternalFilesDir(dir);
    }
	
	// init it in ur application
    public void initConfig() {
		if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                                       .detectDiskReads()
                                       .detectDiskWrites()
                                       .detectNetwork()
                                       .penaltyLog()
                                       .build());
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                                   .detectLeakedClosableObjects()
                                   .detectLeakedSqlLiteObjects()
                                   .penaltyLog()
                                   .build());
        }
	}
	
	// init it in ur application
    public void initLog() {
        LogUtils.Config config = LogUtils.getConfig()
			.setLogSwitch(isDebug())// 设置 log 总开关，包括输出到控制台和文件，默认开
			.setConsoleSwitch(isDebug())// 设置是否输出到控制台开关，默认开
			.setGlobalTag(null)// 设置 log 全局标签，默认为空
			// 当全局标签不为空时，我们输出的 log 全部为该 tag，
			// 为空时，如果传入的 tag 为空那就显示类名，否则显示 tag
			.setLogHeadSwitch(true)// 设置 log 头信息开关，默认为开
			.setLog2FileSwitch(false)// 打印 log 时是否存到文件的开关，默认关
			.setDir("")// 当自定义路径为空时，写入应用的/cache/log/目录中
			.setFilePrefix("")// 当文件前缀为空时，默认为"util"，即写入文件为"util-yyyy-MM-dd$fileExtension"
			.setFileExtension(".log")// 设置日志文件后缀
			.setBorderSwitch(true)// 输出日志是否带边框开关，默认开
			.setSingleTagSwitch(true)// 一条日志仅输出一条，默认开，为美化 AS 3.1 的 Logcat
			.setConsoleFilter(LogUtils.V)// log 的控制台过滤器，和 logcat 过滤器同理，默认 Verbose
			.setFileFilter(LogUtils.V)// log 文件过滤器，和 logcat 过滤器同理，默认 Verbose
			.setStackDeep(1)// log 栈深度，默认为 1
			.setStackOffset(0)// 设置栈偏移，比如二次封装的话就需要设置，默认为 0
			.setSaveDays(3)// 设置日志可保留天数，默认为 -1 表示无限时长
			// 新增 ArrayList 格式化器，默认已支持 Array, Throwable, Bundle, Intent 的格式化输出
			.addFormatter(new LogUtils.IFormatter<ArrayList>() {
				@Override
				public String format(ArrayList arrayList) {
					return "LogUtils Formatter ArrayList { " + arrayList.toString() + " }";
				}
			})
			.setFileWriter(null);
        LogUtils.i(config.toString());
    }

    private void initCrash() {
        CrashUtils.init(new CrashUtils.OnCrashListener() {
				@Override
				public void onCrash(String crashInfo, Throwable e) {
					LogUtils.e(crashInfo);
					AppUtils.relaunchApp();
				}
			});
		try {

            CrashTracker.init(this); //Initializing Sherlock
            CrashTracker.setAppInfoProvider(new AppInfoProvider() {
                    @Override
                    public AppInfo getAppInfo() {
                        return new AppInfo.Builder()
                            .with("Version", AppInfo.getAppVersion(getApplicationContext())) //You can get the actual version using "AppInfoUtil.getAppVersion(context)"
                            .with("BuildNumber", "1")
                            .build();
                    }
                });

        } catch (CrashNotInitializedException e) {
            e.printStackTrace();
        } 
    }

    private boolean isDebug() {
        if (isDebug == null) isDebug = AppUtils.isAppDebug();
        return isDebug;
    }

    public boolean isMainProcess() {
        if (isMainProcess == null) isMainProcess = ProcessUtils.isMainProcess();
        return isMainProcess;
    }

	public File getHomeDir() {
		return new File(getFilesDir(), "home");
	}

	@SuppressLint("SdCardPath")
	public File getFilesDir() {
		return FolderMe.mkdirIfNotExits(new File("/data/data/com.engine/files"));
	}
	
}
