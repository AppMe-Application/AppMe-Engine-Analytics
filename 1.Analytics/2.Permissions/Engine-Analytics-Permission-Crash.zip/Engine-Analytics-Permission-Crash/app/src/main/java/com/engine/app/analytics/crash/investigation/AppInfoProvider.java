package com.engine.app.analytics.crash.investigation;

public interface AppInfoProvider {
  AppInfo getAppInfo();
}
