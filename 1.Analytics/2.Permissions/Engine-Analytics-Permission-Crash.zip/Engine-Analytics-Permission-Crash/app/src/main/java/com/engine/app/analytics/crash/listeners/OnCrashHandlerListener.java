package com.engine.app.analytics.crash.listeners;

import com.engine.app.analytics.crash.investigation.CrashViewModel;
import com.engine.app.analytics.crash.models.AppInfoViewModel;

public interface OnCrashHandlerListener {
    
    void openSendApplicationChooser(String crashDetails);

    void renderAppInfo(AppInfoViewModel viewModel);

    void render(CrashViewModel viewModel);
    
}
