package com.engine.app.analytics;

import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.engine.R;
import com.engine.app.settings.Settings;
import com.engine.app.fragments.UnzipFragment;

public class AnalyticsActivity extends AppCompatActivity {
    public static String TAG = AnalyticsActivity.class.getSimpleName();
	
	private AnalyticsVersion mVersionMe;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Engine_Theme_Application);
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics);
		
		Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
        
        switchFragment(AnalyticsFragment.newInstance("This Is a Example Crash.Click Menu Test For Look Crash Handler..."));
        /*mVersionMe = AnalyticsVersion.with(this);
		boolean isCheckVersion = mVersionMe.isCheckUpdate();
		if(!isCheckVersion){
			mVersionMe.checkUpdate();
		}*/
    }
    
    public void switchFragment(Fragment fragment){
        getSupportFragmentManager()
        .beginTransaction()
        .replace(R.id.content_frame, fragment)
        .commit();
    }

	public void showMessage(String msg) {
		Toast.makeText(AnalyticsActivity.this, msg, Toast.LENGTH_SHORT).show();
    }
}
/*don't forget to subscribe my YouTube channel for more Tutorial and mod*/
/*
https://youtube.com/channel/UC_lCMHEhEOFYgJL6fg1ZzQA */
