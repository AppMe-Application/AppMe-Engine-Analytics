package com.engine.app.analytics;

import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;
import android.content.Intent;

import com.engine.R;
import com.engine.app.analytics.version.VersionChecker;
import com.engine.app.analytics.version.models.UpdateModel;

public class AnalyticsVersion {
    
    private Context mContext;
	private AnalyticsVersion(Context context){
		this.mContext = context;
	}
    public static AnalyticsVersion with(Context context) {      
        return new AnalyticsVersion(context);
    }
    
	public boolean isCheckUpdate(){
		return VersionChecker.getInstance().checkForUpdates(mContext);
	}
	
	public void checkUpdate(){
		VersionChecker update = VersionChecker.with(mContext);
		update.getUpdateVersion();
		update.setOnUpdateVersionListener(new VersionChecker.OnUpdateVersionListener(){
				@Override
				public void onUpdateVersion(final UpdateModel models) {
					new AlertDialog.Builder(mContext)
						.setTitle(R.string.actions_update)
						.setMessage(mContext.getResources().getString(R.string.dialog_update_msg) + " " + models.getVersionCode())
						.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								Toast.makeText(mContext, models.getUrl(), Toast.LENGTH_SHORT).show();
								/*Intent mApplication = new Intent(mContext, UpdateActivity.class);
								mApplication.putExtra(UpdateActivity.EXTRA_NAME, "update-version-code-" + models.getVersionCode() + ".apk");
								mApplication.putExtra(UpdateActivity.EXTRA_PATH, FolderUtil.getDownloadDir(ApplicationActivity.this));
								mApplication.putExtra(UpdateActivity.EXTRA_URL, models.getUrl());
								mContext.startActivity(mApplication);*/
							}
						})
						.setNegativeButton(android.R.string.cancel, null)
						.show();
				}

				@Override
				public void onLatestVersion(UpdateModel models) {
					Toast.makeText(mContext, models.getLatestCode(), Toast.LENGTH_SHORT).show();
				}
			});
	}
}
