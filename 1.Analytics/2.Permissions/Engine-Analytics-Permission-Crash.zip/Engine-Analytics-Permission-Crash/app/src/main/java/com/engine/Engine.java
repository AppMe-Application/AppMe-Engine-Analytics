package com.engine;

import android.util.Log;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.net.Uri;
import android.content.Intent;
import android.provider.Settings;
import android.content.ActivityNotFoundException;


public class Engine {
    
    private static final String TAG = "Engine";

    
	public boolean checkAllFilesAccess(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !Environment.isExternalStorageEmulated()) {
            // Access to all files
            Uri uri = Uri.parse("package:com.engine");
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, uri);
            try {
			context.startActivity(intent);
			return false;
            } catch (ActivityNotFoundException ex) {
                ex.printStackTrace();
                return true;
            }
        }
        return true;
    }
    
}
