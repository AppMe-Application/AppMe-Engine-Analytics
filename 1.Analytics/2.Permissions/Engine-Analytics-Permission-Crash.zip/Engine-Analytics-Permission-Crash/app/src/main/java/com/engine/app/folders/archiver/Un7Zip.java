package com.engine.app.folders.archiver;

import android.content.res.AssetManager;
import android.text.TextUtils;

import java.io.File;

import com.engine.app.folders.archiver.callback.ExtractCallback;

public class Un7Zip {

    public static final long DEFAULT_IN_BUF_SIZE = 0x1000000;
    public static final int SZ_OK = 0;

    public static final int SZ_ERROR_DATA = 1;
    public static final int SZ_ERROR_MEM = 2;
    public static final int SZ_ERROR_CRC = 3;
    public static final int SZ_ERROR_UNSUPPORTED = 4;
    public static final int SZ_ERROR_PARAM = 5;
    public static final int SZ_ERROR_INPUT_EOF = 6;
    public static final int SZ_ERROR_OUTPUT_EOF = 7;
    public static final int SZ_ERROR_READ = 8;
    public static final int SZ_ERROR_WRITE = 9;
    public static final int SZ_ERROR_PROGRESS = 10;
    public static final int SZ_ERROR_FAIL = 11;
    public static final int SZ_ERROR_THREAD = 12;

    public static final int SZ_ERROR_ARCHIVE = 16;
    public static final int SZ_ERROR_NO_ARCHIVE = 17;

    public static final int ERROR_CODE_PATH_ERROR = 999;

	
    public static String getLzmaVersion() {
        return nGetLzmaVersion();
    }

    public static boolean extractFile(String filePath, String outPath, ExtractCallback callback) {
        callback = callback == null ? ExtractCallback.EMPTY_CALLBACK : callback;
        if (TextUtils.isEmpty(filePath) || TextUtils.isEmpty(outPath) || !prepareOutPath(outPath)) {
            callback.onError(ERROR_CODE_PATH_ERROR, "File Path Error!");
            return false;
        }
        return nExtractFile(filePath, outPath, callback, DEFAULT_IN_BUF_SIZE);
    }

    public static boolean extractAsset(AssetManager assetManager, String fileName,
                                       String outPath, ExtractCallback callback) {
        callback = callback == null ? ExtractCallback.EMPTY_CALLBACK : callback;
        if (TextUtils.isEmpty(fileName) || TextUtils.isEmpty(outPath) || !prepareOutPath(outPath)) {
            callback.onError(ERROR_CODE_PATH_ERROR, "File Path Error!");
            return false;
        }
        return nExtractAsset(assetManager, fileName, outPath, callback, DEFAULT_IN_BUF_SIZE);
    }

    private static boolean prepareOutPath(String outPath) {
        File outDir = new File(outPath);
        if (!outDir.exists()) {
            if (outDir.mkdirs())
                return true;
        }
        return outDir.exists() && outDir.isDirectory();
    }

    private static native boolean nExtractFile(String filePath, String outPath,
                                               ExtractCallback callback, long inBufSize);

    private static native boolean nExtractAsset(AssetManager assetManager,
                                                String fileName, String outPath,
                                                ExtractCallback callback, long inBufSize);

    private static native String nGetLzmaVersion();

    static {
        System.loadLibrary("un7zip");
    }
}
