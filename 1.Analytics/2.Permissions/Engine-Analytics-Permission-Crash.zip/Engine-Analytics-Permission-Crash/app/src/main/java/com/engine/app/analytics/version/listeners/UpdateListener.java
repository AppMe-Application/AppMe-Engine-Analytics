package com.engine.app.analytics.version.listeners;

import org.json.JSONObject;

import com.engine.app.analytics.version.models.UpdateModel;

public interface UpdateListener {
    void onJsonDataReceived(UpdateModel updateModel, JSONObject jsonObject);
    void onError(String error);
}
