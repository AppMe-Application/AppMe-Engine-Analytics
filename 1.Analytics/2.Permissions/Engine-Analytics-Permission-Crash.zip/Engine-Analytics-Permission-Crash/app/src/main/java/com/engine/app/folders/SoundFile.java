package com.engine.app.folders;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.engine.AppController;

public class SoundFile {

    private static final String TAG = "SoundFile";
	private Context context;
    private MediaPlayer mMediaPlayer;

    public static String SOUND_FOLDER = FolderMe.EXTERNAL_DIR + "/Android/data/com.engine/files/sound/";
    public static String SOUND_ADD_FILE = "sound_add.mp3";
    public static String SOUND_ERROR = "sound_error.mp3";
    public static String SOUND_BEEP = "sound_beep.ogg";
    public static String SOUND_CLICK = "sound_click.wav";
    public static String SOUND_DONE = "sound_done.mp3";
    public static String SOUND_START_TASK = "sound_start_task.wav";
    public static String SOUND_SUCCESS_TASK = "sound_add.mp3";
    public static String SOUND_TYPING = "sound_typing.ogg";
    public static String SOUND_JUMPING = "sound_jumping.ogg";
    public static String SOUND_JUMPING_FAILED = "sound_jumping_failed.ogg";
	private ExecutorService mExecutor;

    private SoundFile(final Context context) {
        this.context = context;
		mExecutor = Executors.newSingleThreadExecutor();
        mExecutor.submit(new Runnable(){
				@Override
				public void run() {

			    }
			});
	}

	public static SoundFile with(Context context) {
        return new SoundFile(context);
    }
	
    public static SoundFile getInstance() {
        return new SoundFile(AppController.getContext());
    }

    public void setSound(SoundTrack media) {
        String sound = null;
        try {
            switch (media) {
                case SOUND_ADD_FILE:
                    sound = Sound.SOUND_ADD_FILE;
                    break;
                case SOUND_ERROR:            
                    sound = Sound.SOUND_ERROR;
                    break;
                case SOUND_DONE:
                    sound = Sound.SOUND_DONE;
                    break;  
                case SOUND_WRITTING:
                    sound = Sound.SOUND_WRITTING;
                    break;  
                case SOUND_JUMPING:
                    sound = Sound.SOUND_JUMPING;
                    break;  
                case SOUND_JUMPING_FAILED:
                    sound = Sound.SOUND_JUMPING_FAILED;
                    break;     
            }
            soundPlay(sound);
        } catch (Exception e) {
            Log.e(TAG, "error: " + e.getMessage(), e);
        }
    }

    public static String getSound(String sound) {
        return SOUND_FOLDER + sound;
    }

    public void soundPlay(String sound) {

        try {

            mMediaPlayer = new MediaPlayer();
            mMediaPlayer.setDataSource(sound);
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        mp.release();
                    }
                });
            mMediaPlayer.prepare();
            mMediaPlayer.start();
        } catch (Exception e) {
            Log.e(TAG, "error: " + e.getMessage(), e);
        }

    }

    public void getSoundAdd() {
        soundPlay(Sound.SOUND_ADD_FILE);
    }

    public void getSoundError() {
        soundPlay(Sound.SOUND_ERROR);
    }

    public void getSoundComplete() {
        soundPlay(Sound.SOUND_DONE);
    }

    public void getSoundWritter() {
        soundPlay(Sound.SOUND_WRITTING);
    }

    public void release() {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
    }

    public interface Sound {
        String SOUND_ADD_FILE = SOUND_FOLDER + "sound_add.mp3";
        String SOUND_ERROR = SOUND_FOLDER + "sound_error.mp3";
        String SOUND_BEEP = SOUND_FOLDER + "sound_beep.ogg";
        String SOUND_CLICK = SOUND_FOLDER + "sound_click.wav";
        String SOUND_DONE = SOUND_FOLDER + "sound_done.mp3";
        String SOUND_START_TASK = SOUND_FOLDER + "sound_start_task.wav";
        String SOUND_SUCCESS_TASK = SOUND_FOLDER + "sound_add.mp3";
        String SOUND_WRITTING = SOUND_FOLDER + "sound_typing.ogg";
        String SOUND_JUMPING = SOUND_FOLDER + "sound_jumping.ogg";
        String SOUND_JUMPING_FAILED = "sound_jumping_failed.ogg";        
    }

    public enum SoundTrack {
        SOUND_ADD_FILE, 
        SOUND_ERROR, 
        SOUND_DONE, 
        SOUND_BEEP, 
        SOUND_CLICK, 
        SOUND_START_TASK, 
        SOUND_SUCCESS_TASK, 
        SOUND_WRITTING, 
        SOUND_JUMPING, 
        SOUND_JUMPING_FAILED
		}
}
