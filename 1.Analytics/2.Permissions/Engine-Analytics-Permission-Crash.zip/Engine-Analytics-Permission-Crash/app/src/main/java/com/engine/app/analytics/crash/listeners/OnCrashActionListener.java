package com.engine.app.analytics.crash.listeners;

import com.engine.app.analytics.crash.models.CrashesViewModel;

public interface OnCrashActionListener {
    
  void render(CrashesViewModel viewModel);

  void openCrashDetails(int crashId);
}
