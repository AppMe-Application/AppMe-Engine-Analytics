package com.engine;

import androidx.multidex.MultiDexApplication;
import android.app.AlarmManager;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;

import java.io.File;
import android.annotation.SuppressLint;
import com.engine.app.folders.FolderMe;

public class BaseApplication extends MultiDexApplication {

    private static BaseApplication sInstance;

    public static BaseApplication getInstance() {
        return sInstance;
    }

    private Boolean isDebug;
    private Boolean isMainProcess;
	private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;
	
    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
		
        
        initCrash();
        //initDebugMenu();
    }

  

    private void initCrash() {
        
		this.uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
		Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
				@Override
				public void uncaughtException(Thread thread, Throwable ex) {
					Intent intent = new Intent(getApplicationContext(), DebugActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
					intent.putExtra("error", getStackTrace(ex));
					PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 11111, intent, PendingIntent.FLAG_ONE_SHOT);
					AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
					am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, pendingIntent);
					android.os.Process.killProcess(android.os.Process.myPid());
					System.exit(2);
					uncaughtExceptionHandler.uncaughtException(thread, ex);
				}
			});
    }

    
	private String getStackTrace(Throwable th){
		final Writer result = new StringWriter();
		final PrintWriter printWriter = new PrintWriter(result);
		Throwable cause = th;
		while(cause != null){
			cause.printStackTrace(printWriter);
			cause = cause.getCause();
		}
		final String stacktraceAsString = result.toString();
		printWriter.close();
		return stacktraceAsString;
	}
	
	public File getHomeDir() {
		return new File(getFilesDir(), "home");
	}

}
