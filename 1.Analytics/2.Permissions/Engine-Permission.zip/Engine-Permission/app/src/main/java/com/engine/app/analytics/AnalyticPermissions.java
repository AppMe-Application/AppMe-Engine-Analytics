package com.engine.app.analytics;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.text.TextUtils;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import com.engine.R;
import com.engine.app.analytics.permission.Action;
import com.engine.app.analytics.permission.AndPermission;
import com.engine.app.analytics.permission.runtime.PermissionDef;
import com.engine.app.analytics.permission.runtime.Permission;
import com.engine.app.analytics.permission.task.TaskExecutor;
import com.engine.app.analytics.rationals.RuntimeRationale;
import com.engine.app.analytics.rationals.WriteSettingRationale;
import com.engine.app.analytics.rationals.NotifyListenerRationale;
import com.engine.app.analytics.rationals.NotifyRationale;
import com.engine.app.analytics.rationals.InstallRationale;
import com.engine.app.folders.FileUtils;
import com.engine.app.folders.IOUtils;

public class AnalyticPermissions {
	
    private static final int REQUEST_CODE_SETTING = 1;
	
    private Context mContext;
	private OnAnalyticsPermissionListener mOnAnalyticsPermissionListener;
    private AnalyticPermissions(Context context){
		this.mContext = context;
	}
	
	public static AnalyticPermissions with(Context context){
		return new AnalyticPermissions(context);
	}
	
	/**
     * Request permissions.
     */
    public void requestPermission(@PermissionDef String[] permissions, final OnAnalyticsPermissionListener mOnPermissionListener) {
        AndPermission.with(mContext)
            .runtime()
            .permission(permissions)
            .rationale(new RuntimeRationale())
            .onGranted(new Action<List<String>>() {
                @Override
                public void onAction(List<String> permissions) {
                    String message = mContext.getString(R.string.analytics_permission_successfully);
					if(mOnPermissionListener != null){
						mOnPermissionListener.onGranted(message, permissions);
					}
                }
            })
            .onDenied(new Action<List<String>>() {
                @Override
                public void onAction(@NonNull List<String> permissions) {
                    String message = mContext.getString(R.string.analytics_permission_failure);
					if(mOnPermissionListener != null){
						mOnPermissionListener.onDenied(message, permissions);
					}
                    if (AndPermission.hasAlwaysDeniedPermission(mContext, permissions)) {
                        showSettingDialog(mContext, permissions);
                    }
                }
            })
            .start();
    }

	/**
     * Request notification permission.
     */
    public void requestNotification() {
        AndPermission.with(mContext)
            .notification()
            .permission()
            .rationale(new NotifyRationale())
            .onGranted(new Action<Void>() {
                @Override
                public void onAction(Void data) {
                    toast(R.string.analytics_permission_successfully);
                }
            })
            .onDenied(new Action<Void>() {
                @Override
                public void onAction(Void data) {
                    toast(R.string.analytics_permission_failure);
                }
            })
            .start();
    }

    /**
     * Request notification listener.
     */
    public void requestNotificationListener() {
        AndPermission.with(mContext)
            .notification()
            .listener()
            .rationale(new NotifyListenerRationale())
            .onGranted(new Action<Void>() {
                @Override
                public void onAction(Void data) {
                    toast(R.string.analytics_permission_successfully);
                }
            })
            .onDenied(new Action<Void>() {
                @Override
                public void onAction(Void data) {
                    toast(R.string.analytics_permission_failure);
                }
            })
            .start();
    }
	
	/**
     * Request to read and write external storage permissions.
     */
    public void requestPermissionForInstallPackage() {
        if (!FileUtils.externalAvailable()) {
            new AlertDialog.Builder(mContext)
                .setTitle(R.string.permission_title_dialog)
                .setMessage(R.string.permission_message_error_storeage_inavailable)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
            return;
        }

        AndPermission.with(mContext)
            .runtime()
            .permission(Permission.Group.STORAGE)
            .rationale(new RuntimeRationale())
            .onGranted(new Action<List<String>>() {
                @Override
                public void onAction(List<String> data) {
                    writeApkForInstallPackage();
                }
            })
            .onDenied(new Action<List<String>>() {
                @Override
                public void onAction(List<String> data) {
                    toast(R.string.permission_message_install_failed);
                }
            })
            .start();
    }

    private void writeApkForInstallPackage() {
        new TaskExecutor<File>(mContext) {
            @Override
            protected File doInBackground(Void... voids) {
                try {
                    InputStream input = mContext.getAssets().open("android.apk");
                    File apk = new File(FileUtils.getExternalDir(mContext, Environment.DIRECTORY_DOWNLOADS), "AndPermission.apk");
                    if (apk.exists()) return apk;

                    OutputStream output = new BufferedOutputStream(new FileOutputStream(apk));

                    IOUtils.write(input, output);
                    IOUtils.close(output);

                    return apk;
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onFinish(File apkFile) {
                if (apkFile == null) {
                    new AlertDialog.Builder(mContext)
                        .setTitle(R.string.permission_title_dialog)
                        .setMessage(R.string.permission_message_error_save_failed)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        })
                        .show();
                } else {
                    installPackage(apkFile);
                }
            }
        }.execute();
    }

    /**
     * Install package.
     */
    private void installPackage(File apkFile) {
        AndPermission.with(mContext)
            .install()
            .file(apkFile)
            .rationale(new InstallRationale())
            .onGranted(new Action<File>() {
                @Override
                public void onAction(File data) {
                    // Installing.
                }
            })
            .onDenied(new Action<File>() {
                @Override
                public void onAction(File data) {
                    // The user refused to install.
                }
            })
            .start();
    }
	
    /**
     * Display setting dialog.
     */
    public void showSettingDialog(Context context, final List<String> permissions) {
        List<String> permissionNames = Permission.transformText(context, permissions);
        String message = context.getString(R.string.permission_message_always_failed, TextUtils.join("\n", permissionNames));

        new AlertDialog.Builder(context).setCancelable(false)
            .setTitle(R.string.permission_title_dialog)
            .setMessage(message)
            .setPositiveButton(R.string.action_setting, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    setPermission();
                }
            })
            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            })
            .show();
    }

    /**
     * Set permissions.
     */
    public void setPermission() {
        AndPermission.with(mContext).runtime().setting().start(REQUEST_CODE_SETTING);
    }

    
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_SETTING: {
					Toast.makeText(mContext, R.string.permission_message_setting_comeback, Toast.LENGTH_SHORT).show();
					break;
				}
        }
    }
	
	public void requestWriteSystemSetting() {
        AndPermission.with(mContext).setting().write().rationale(new WriteSettingRationale()).onGranted(new Action<Void>() {
				@Override
				public void onAction(Void data) {
					toast(R.string.analytics_permission_successfully);
				}
			}).onDenied(new Action<Void>() {
				@Override
				public void onAction(Void data) {
					toast(R.string.analytics_permission_failure);
				}
			}).start();
    }
	
	private void toast(@StringRes int message) {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }
	
	public void setOnAnalyticsPermissionListener(OnAnalyticsPermissionListener mOnAnalyticsPermissionListener){
		this.mOnAnalyticsPermissionListener = mOnAnalyticsPermissionListener;
	}
	
	public interface OnAnalyticsPermissionListener{
		void onGranted(String message, List<String> permissions);
		void onDenied(String message, List<String> permissions);
	}
}
