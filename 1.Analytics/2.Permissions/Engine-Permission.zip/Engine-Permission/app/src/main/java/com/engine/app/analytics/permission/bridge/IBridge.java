package com.engine.app.analytics.permission.bridge;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

import com.engine.app.analytics.permission.bridge.IBridge;
import com.engine.app.analytics.permission.bridge.IBridge.Stub;

public interface IBridge extends IInterface {
    Stub sInstance;
	
    public static abstract class Stub extends Binder implements IBridge {
        private static final String DESCRIPTOR = "com.engine.app.analytics.permission.bridge.IBridge";
        static final int TRANSACTION_requestAlertWindow_String = 5;
        static final int TRANSACTION_requestAppDetails_String = 1;
        static final int TRANSACTION_requestInstall_String = 3;
        static final int TRANSACTION_requestNotificationListener_String = 7;
        static final int TRANSACTION_requestNotify_String = 6;
        static final int TRANSACTION_requestOverlay_String = 4;
        static final int TRANSACTION_requestPermission_String_String¥ = 2;
        static final int TRANSACTION_requestWriteSetting_String = 8;
		public Stub() {
            attachInterface(this, DESCRIPTOR);
        }
		
        private static class Proxy implements IBridge {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                IBinder iBinder2 = iBinder;
                this.mRemote = iBinder2;
            }

            @Override
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                Proxy proxy = this;
                return DESCRIPTOR;
            }

            @Override
            public void requestAppDetails(String str) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestAppDetails_String, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }

            @Override
            public void requestPermission(String str, String[] strArr) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                String[] strArr2 = strArr;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    obtain.writeStringArray(strArr2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestPermission_String_String¥, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }

            @Override
            public void requestInstall(String str) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestInstall_String, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }

            @Override
            public void requestOverlay(String str) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestOverlay_String, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }

            @Override
            public void requestAlertWindow(String str) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestAlertWindow_String, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }

            @Override
            public void requestNotify(String str) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestNotify_String, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }

            @Override
            public void requestNotificationListener(String str) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestNotificationListener_String, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }

            @Override
            public void requestWriteSetting(String str) throws RemoteException {
                Proxy proxy = this;
                String str2 = str;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(DESCRIPTOR);
                    obtain.writeString(str2);
                    boolean transact = proxy.mRemote.transact(Stub.TRANSACTION_requestWriteSetting_String, obtain, obtain2, 0);
                    obtain2.readException();
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    obtain2.recycle();
                    obtain.recycle();
                    Throwable th3 = th2;
                }
            }
        }

        
        public static IBridge asInterface(IBinder iBinder) {
            IBinder iBinder2 = iBinder;
            if (iBinder2 == null) {
                return (IBridge) null;
            }
            IInterface queryLocalInterface = iBinder2.queryLocalInterface(DESCRIPTOR);
            if (queryLocalInterface != null && (queryLocalInterface instanceof IBridge)) {
                return (IBridge) queryLocalInterface;
            }
            
            Proxy proxy = new Proxy(iBinder2);
            return proxy;
        }

        @Override
        public IBinder asBinder() {
            sInstance = this;
            return sInstance;
        }

        @Override
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            Binder binder = this;
            int i3 = i;
            Parcel parcel3 = parcel;
            Parcel parcel4 = parcel2;
            int i4 = i2;
            String str = DESCRIPTOR;
            switch (i3) {
                case TRANSACTION_requestAppDetails_String /*1*/:
                    parcel3.enforceInterface(str);
                    requestAppDetails(parcel3.readString());
                    parcel4.writeNoException();
                    return true;
                case TRANSACTION_requestPermission_String_String¥ /*2*/:
                    parcel3.enforceInterface(str);
                    requestPermission(parcel3.readString(), parcel3.createStringArray());
                    parcel4.writeNoException();
                    return true;
                case TRANSACTION_requestInstall_String /*3*/:
                    parcel3.enforceInterface(str);
                    requestInstall(parcel3.readString());
                    parcel4.writeNoException();
                    return true;
                case TRANSACTION_requestOverlay_String /*4*/:
                    parcel3.enforceInterface(str);
                    requestOverlay(parcel3.readString());
                    parcel4.writeNoException();
                    return true;
                case TRANSACTION_requestAlertWindow_String /*5*/:
                    parcel3.enforceInterface(str);
                    requestAlertWindow(parcel3.readString());
                    parcel4.writeNoException();
                    return true;
                case TRANSACTION_requestNotify_String /*6*/:
                    parcel3.enforceInterface(str);
                    requestNotify(parcel3.readString());
                    parcel4.writeNoException();
                    return true;
                case TRANSACTION_requestNotificationListener_String /*7*/:
                    parcel3.enforceInterface(str);
                    requestNotificationListener(parcel3.readString());
                    parcel4.writeNoException();
                    return true;
                case TRANSACTION_requestWriteSetting_String /*8*/:
                    parcel3.enforceInterface(str);
                    requestWriteSetting(parcel3.readString());
                    parcel4.writeNoException();
                    return true;
                case 1598968902:
                    parcel4.writeString(str);
                    return true;
                default:
                    return super.onTransact(i3, parcel3, parcel4, i4);
            }
        }
    }

    void requestAlertWindow(String str) throws RemoteException;

    void requestAppDetails(String str) throws RemoteException;

    void requestInstall(String str) throws RemoteException;

    void requestNotificationListener(String str) throws RemoteException;

    void requestNotify(String str) throws RemoteException;

    void requestOverlay(String str) throws RemoteException;

    void requestPermission(String str, String[] strArr) throws RemoteException;

    void requestWriteSetting(String str) throws RemoteException;
}
