package com.engine.app.analytics.rationals;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.engine.R;
import com.engine.app.analytics.permission.Rationale;
import com.engine.app.analytics.permission.RequestExecutor;

/**
 * Created by Zhenjie Yan on 3/1/19.
 */
public class WriteSettingRationale implements Rationale<Void> {

    @Override
    public void showRationale(Context context, Void data, final RequestExecutor executor) {
        new AlertDialog.Builder(context).setCancelable(false)
            .setTitle(R.string.permission_title_dialog)
            .setMessage(R.string.permission_message_write_setting_failed)
            .setPositiveButton(R.string.action_setting, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    executor.execute();
                }
            })
            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    executor.cancel();
                }
            })
            .show();
    }
}
