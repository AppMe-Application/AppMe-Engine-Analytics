package com.engine;

import android.Manifest;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.UriPermission;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.view.View;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.engine.app.folders.FolderMe;
import com.engine.app.folders.FolderMePreference;
import com.engine.app.folders.archiver.Un7Zip;
import com.engine.app.folders.archiver.callback.ExtractCallback;
import com.engine.app.analytics.AnalyticPermissions;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
	private static final int REQUEST_READ_EXTERNAL_STORAGE = 1;

	private SharedPreferences Sp;
	private int operation;
    
    private TextView mText7zVersion;
    private TextView mTextFilePath;
    private Button mButtonChooseFile;
    private Button mButtonExtract;
    private Button mButtonExtractAsset;
    private TextView mTextOutputPath;

    private String mOutputPath;
    private String mInputFilePath;
    private ProgressDialog mProgressDialog;
    private ExecutorService mExecutor;
	private AnalyticPermissions mAnalytics;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
        } catch (Exception e) {
            e.printStackTrace();
        }
		System.out.println("onCreate");
        Sp = PreferenceManager.getDefaultSharedPreferences(this);

        setContentView(R.layout.activity_main);

		Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);

		mText7zVersion = findViewById(R.id.text_7z_version);
		mTextFilePath = findViewById(R.id.text_file_path);
		mButtonChooseFile = findViewById(R.id.button_choose_file);
		mButtonChooseFile.setOnClickListener(this);
		mButtonExtract = findViewById(R.id.button_extract);
		mButtonExtract.setOnClickListener(this);
		mButtonExtractAsset = findViewById(R.id.button_extract_asset);
		mButtonExtractAsset.setOnClickListener(this);
		mTextOutputPath = findViewById(R.id.text_output_path);

		mProgressDialog = new ProgressDialog(this);
        mExecutor = Executors.newSingleThreadExecutor();
        mText7zVersion.setText(Un7Zip.getLzmaVersion());
		mAnalytics = AnalyticPermissions.with(this);
        File outFile = getExternalFilesDir("extracted");
        if (outFile == null || !outFile.exists()) {
            outFile = getFilesDir();
        }
        mOutputPath = outFile.getPath();
        mTextOutputPath.setText(mOutputPath);
    }

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
			case R.id.button_choose_file:
				final Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
				intent.addCategory(Intent.CATEGORY_OPENABLE);
				intent.setType("*/*");

				/*if (Build.VERSION.SDK_INT >= 26)
				 intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, Uri.parse(FolderMePreference.getWorkingFile(this)));*/
				startActivityForResult(intent, REQUEST_READ_EXTERNAL_STORAGE);

				break;
			case R.id.button_extract:
				mAnalytics.requestPermission(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, new AnalyticPermissions.OnAnalyticsPermissionListener(){
						@Override
						public void onGranted(String message, List<String> permissions) {
							String zipFile = FolderMePreference.getWorkingFile(MainActivity.this);
							if (TextUtils.isEmpty(zipFile)) {
								showMessage("Please Select 7z File First!");
								return;
							} 
							doExtractFile(zipFile);
						}

						@Override
						public void onDenied(String message, List<String> permissions) {
							showMessage("Permission Denied!");
						}
				});	
				break;
			case R.id.button_extract_asset:

				mAnalytics.requestPermission(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, new AnalyticPermissions.OnAnalyticsPermissionListener(){	
				    	@Override
						public void onGranted(String message, List<String> permissions) {
							String assetFile = "TestAsset.7z";
							if (TextUtils.isEmpty(assetFile)) {
								showMessage("Asset File Not Found!");
								return;
							}
							doExtractAssets(assetFile);
						}

						@Override
						public void onDenied(String message, List<String> permissions) {
							showMessage("Permission Denied!");
						}
					});
				break;
		}
	}


	/**
     * real extract process
     */
    private void doExtractFile(final String file7Zip) {
        mProgressDialog.show();
		getSupportActionBar().setSubtitle(file7Zip);
        mExecutor.submit(new Runnable(){
				@Override
				public void run() {
					Un7Zip.extractFile(file7Zip, mOutputPath, new ExtractCallback() {
							@Override
							public void onProgress(final String name, final long size) {
								runOnUiThread(new Runnable(){
										@Override
										public void run() {
											mProgressDialog.setMessage("name: " + name + "\nsize: " + size);
										}
									});
							}

							@Override
							public void onError(final int errorCode, final String message) {
								runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage(message);
											mProgressDialog.dismiss();
										}
									});
							}

							@Override
							public void onSucceed() {
								runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage("Succeed!!");
											mProgressDialog.dismiss();
										}
									});
							}

						});
				}
			});
    }


	/**
     * real extract process
     */
    private void doExtractAssets(final String file7Zip) {
		mProgressDialog.show();
		mExecutor.submit(new Runnable(){
				@Override
				public void run() {
					Un7Zip.extractAsset(getAssets(), file7Zip,
						mOutputPath, new ExtractCallback() {
							@Override
							public void onProgress(final String name, final long size) {
								runOnUiThread(new Runnable(){
										@Override
										public void run() {
											mProgressDialog.setMessage("name: " + name + "\nsize: " + size);
										}
									});
							}

							@Override
							public void onError(final int errorCode, final String message) {
								runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage(message);
											mProgressDialog.dismiss();
										}
									});
							}

							@Override
							public void onSucceed() {
								runOnUiThread(new Runnable(){
										@Override
										public void run() {
											showMessage("Succeed!!");
											mProgressDialog.dismiss();
										}
									});
							}
						});
				}
			});
    }

	@Override
	protected void onActivityResult(final int requestCode, int resultCode, Intent intent) {
		if (requestCode == REQUEST_READ_EXTERNAL_STORAGE) {
			if (resultCode == Activity.RESULT_OK) {
				final Uri uri = intent.getData();
                boolean uriAlreadyTaken = false;

                // https://commonsware.com/blog/2020/06/13/count-your-saf-uri-permission-grants.html
                final ContentResolver contentResolver = getContentResolver();
				final int takeFlags = intent.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                for (UriPermission persistedUri : contentResolver.getPersistedUriPermissions()) {
                    if (persistedUri.getUri().equals(uri)) {
                        uriAlreadyTaken = true;
                    } else {
                        contentResolver.releasePersistableUriPermission(persistedUri.getUri(), takeFlags);
                    }
                }

                if (!uriAlreadyTaken) {
                    try {
                        contentResolver.takePersistableUriPermission(uri, takeFlags);
                    } catch (SecurityException e) {
                        e.printStackTrace();
                    }
                }
				mInputFilePath = uri.getPath();
				FolderMePreference.setWorkingFile(this, mInputFilePath);
				showMessage("Choose File:" + mInputFilePath);
				mTextFilePath.setText(mInputFilePath);
			}
		} else if (requestCode == 3) {
			String p = Sp.getString("URI", null);
			Uri oldUri =null;
			if (p != null)oldUri = Uri.parse(p);
			Uri treeUri = null;
			if (resultCode == Activity.RESULT_OK) {
				// Get Uri from Storage Access Framework.
				treeUri = intent.getData();
				// Persist URI - this is required for verification of writability.
				if (treeUri != null)Sp.edit().putString("URI", treeUri.toString()).commit();
			}

			// If not confirmed SAF, or if still not writable, then revert settings.
			if (resultCode != Activity.RESULT_OK) {
				/* DialogUtil.displayError(getActivity(), R.string.message_dialog_cannot_write_to_folder_saf, false,
				 currentFolder);||!FileUtil.isWritableNormalOrSaf(currentFolder)
				 */
				Sp.edit().putString("URI", oldUri.toString()).commit();
				return;
			}

			// After confirmation, update stored value of folder.
			// Persist access permissions.
			final int takeFlags = intent.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			switch (operation) {
				case 0://deletion
					File dir = new File(treeUri.getPath() + File.separator + getString(getApplicationInfo().labelRes));
					
					break;
				case 1://copying

					break;
				case 2://moving
					break;
				case 3://mkdir

					break;
				case 4:
					//FileUtil.renameFolder(new File(oppathe),new File(oppathe1),mainActivity);

					break;

			}
		} else {
            super.onActivityResult(requestCode, resultCode, intent);
        }

	}

	@Override
    protected void onDestroy() {
        mExecutor.shutdownNow();
        super.onDestroy();
    }

    private void showMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }


}
/*don't forget to subscribe my YouTube channel for more Tutorial and mod*/
/*
https://youtube.com/channel/UC_lCMHEhEOFYgJL6fg1ZzQA */
