package com.engine.app.folders;

import android.annotation.SuppressLint;
import androidx.annotation.NonNull;

import java.io.File;
import com.engine.BaseApplication;

public class FolderMe {
    
    public static final String DEFAULT_ROOT = "/data/data/com.engine/files";
	public static final String DEFAULT_HOME = DEFAULT_ROOT + "/home";
	public static File ROOT;
	public static File HOME;
	
    public static void init() {
		final BaseApplication app = BaseApplication.getInstance();
		ROOT = app.getFilesDir();
		
    }
	
	
}
