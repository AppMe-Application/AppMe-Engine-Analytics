package com.engine;

import androidx.appcompat.app.AppCompatDelegate;

public class AppController extends BaseApplication {

	@Override
	public void onCreate() {
		super.onCreate();
		AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
		
	}
	
}
