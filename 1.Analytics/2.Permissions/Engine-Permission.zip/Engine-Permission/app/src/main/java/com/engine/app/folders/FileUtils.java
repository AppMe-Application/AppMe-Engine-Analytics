package com.engine.app.folders;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import java.io.File;

/**
 * Created Zhenjie Yan on 2019-10-10.
 */
public class FileUtils {

    public static File getFileDir(Context context) {
        return getFileDir(context, null);
    }

    public static File getFileDir(Context context, @Nullable String type) {
        File root = context.getFilesDir();
        if (TextUtils.isEmpty(type)) {
            return root;
        } else {
            File dir = new File(root, type);
            createDir(dir);
            return dir;
        }
    }

    public static boolean externalAvailable() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    public static File getExternalDir(Context context) {
        return getExternalDir(context, null);
    }

    public static File getExternalDir(Context context, @Nullable String type) {
        if (externalAvailable()) {
            if (TextUtils.isEmpty(type)) {
                return context.getExternalFilesDir(null);
            }

            File dir = context.getExternalFilesDir(type);
            if (dir == null) {
                dir = context.getExternalFilesDir(null);
                dir = new File(dir, type);
                createDir(dir);
            }

            return dir;
        }
        throw new RuntimeException("External storage device is not available.");
    }

    public static File getRootDir() {
        return getRootDir(null);
    }

    public static File getRootDir(@Nullable String type) {
        if (externalAvailable()) {
            File root = Environment.getExternalStorageDirectory();
            File appRoot = new File(root, "AndPermission");
            createDir(appRoot);

            if (TextUtils.isEmpty(type)) {
                return appRoot;
            }

            File dir = new File(appRoot, type);
            createDir(dir);

            return dir;
        }
        throw new RuntimeException("External storage device is not available.");
    }

    public static void createDir(File dir) {
        if (dir.exists()) {
            if (!dir.isDirectory()) {
                dir.delete();
            }
        }
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }
}
